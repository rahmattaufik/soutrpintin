<?php $__env->startSection('title', 'Hubungi Kami — Soutprint.In'); ?>
<?php $__env->startSection('meta_description', 'Hubungi tim web engineer Soutprint.In untuk konsultasi gratis mengenai kebutuhan pembuatan website dan transformasi digital bisnis Anda.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Contact Header with Bold, Large Sweeping Wave Effect -->
    <section class="pt-16 pb-24 md:pt-20 md:pb-32 bg-white relative overflow-hidden border-b border-slate-200/80">
        <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute inset-0 bg-mesh-contact"></div>
            <div class="absolute -top-16 left-1/4 w-[500px] h-[300px] bg-indigo-500/12 rounded-full blur-[100px]"></div>
            <div class="absolute top-1/4 -right-10 w-[450px] h-[300px] bg-cyan-400/12 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-4">
                <i class="fa-solid fa-headset text-indigo-600"></i>
                <span>Konsultasi &amp; Diskusi Proyek</span>
            </div>
            <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight font-heading">
                Hubungi <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Soutprint.In</span>
            </h1>
            <p class="mt-4 text-sm sm:text-base md:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
                Siap mewujudkan website impian Anda? Diskusikan ide proyek Anda hari ini dengan technical consultant kami.
            </p>
        </div>

        <!-- Dramatic Curved Bottom Wave Divider to Section Below -->
        <div class="absolute bottom-0 left-0 w-full overflow-hidden leading-none select-none pointer-events-none -mb-[1px]">
            <svg class="relative block w-full h-8 sm:h-16 text-[#FAFAFC]" viewBox="0 0 1440 70" fill="none" preserveAspectRatio="none">
                <path d="M0,25 C360,65 720,5 1080,45 C1260,65 1380,30 1440,20 L1440,70 L0,70 Z" fill="#FAFAFC"></path>
            </svg>
        </div>
    </section>

    <!-- Main Contact Section -->
    <section class="py-12 sm:py-16 md:py-24 bg-[#FAFAFC] relative overflow-hidden">
        <!-- Modern Tech Background: Ambient Glow + Grid tipis (Crystal Clear Form Inputs) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute top-1/4 -right-16 w-[450px] h-[350px] bg-indigo-500/10 rounded-full blur-[110px]"></div>
            <div class="absolute bottom-10 -left-16 w-[450px] h-[350px] bg-cyan-400/10 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
                
                <!-- Left: Contact Details (5 cols) -->
                <div class="lg:col-span-5 space-y-6 sm:space-y-8">
                    <div>
                        <span class="text-xs font-bold uppercase tracking-wider text-indigo-600">Informasi Kontak</span>
                        <h2 class="text-xl sm:text-2xl md:text-3xl font-extrabold text-slate-900 font-heading mt-1">Kami Siap Membantu Anda</h2>
                        <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                            Jangan ragu untuk menghubungi kami untuk bertanya seputar biaya, fitur kustom, atau sekadar bertukar pikiran mengenai proyek web Anda.
                        </p>
                    </div>

                    <div class="space-y-4 sm:space-y-5">
                        <div class="flex items-start gap-3.5 sm:gap-4 p-3.5 sm:p-4 rounded-xl sm:rounded-2xl bg-white border border-slate-200 shadow-xs">
                            <div class="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center text-lg flex-shrink-0">
                                <i class="fa-brands fa-whatsapp"></i>
                            </div>
                            <div>
                                <span class="text-xs text-slate-500 font-bold block">WhatsApp Fast Response</span>
                                <a href="https://wa.me/6281234567890" target="_blank" class="text-sm font-bold text-slate-900 hover:text-emerald-600 transition-colors">
                                    +62 812-3456-7890
                                </a>
                                <p class="text-[11px] text-slate-500 mt-0.5">Respon cepat dalam hitungan menit</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
                            <div class="w-11 h-11 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-200 flex items-center justify-center text-lg flex-shrink-0">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <span class="text-xs text-slate-500 font-bold block">Email Korespondensi</span>
                                <a href="mailto:halo@soutprint.in" class="text-sm font-bold text-slate-900 hover:text-indigo-600 transition-colors">
                                    halo@soutprint.in
                                </a>
                                <p class="text-[11px] text-slate-500 mt-0.5">Untuk penawaran resmi & proposal RFP</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
                            <div class="w-11 h-11 rounded-xl bg-cyan-50 text-cyan-600 border border-cyan-200 flex items-center justify-center text-lg flex-shrink-0">
                                <i class="fa-solid fa-clock"></i>
                            </div>
                            <div>
                                <span class="text-xs text-slate-500 font-bold block">Jam Kerja Operasional</span>
                                <span class="text-sm font-bold text-slate-900">Senin - Sabtu: 08:30 - 20:00 WIB</span>
                                <p class="text-[11px] text-slate-500 mt-0.5">Dukungan darurat server 24/7</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
                            <div class="w-11 h-11 rounded-xl bg-purple-50 text-purple-600 border border-purple-200 flex items-center justify-center text-lg flex-shrink-0">
                                <i class="fa-solid fa-location-dot"></i>
                            </div>
                            <div>
                                <span class="text-xs text-slate-500 font-bold block">Lokasi Studio</span>
                                <span class="text-sm font-bold text-slate-900">Jakarta & Surabaya, Indonesia</span>
                                <p class="text-[11px] text-slate-500 mt-0.5">Layanan ke seluruh Indonesia & mancanegara</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right: Contact Form (7 cols) -->
                <div class="lg:col-span-7 bg-white border border-slate-200 rounded-2xl sm:rounded-3xl p-5 sm:p-8 md:p-10 shadow-md">
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 font-heading mb-1">Kirim Pesan atau Rincian Proyek</h3>
                    <p class="text-xs sm:text-sm text-slate-600 mb-5 sm:mb-6">Silakan isi formulir berikut, kami akan menghubungi Anda segera.</p>

                    <form id="contact-form" action="<?php echo e(route('contact.submit')); ?>" method="POST" class="space-y-4">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="source" id="modal-source" value="Halaman Kontak">

                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1.5">Nama Lengkap / Nama Bisnis *</label>
                            <input type="text" name="name" id="modal-name" required placeholder="Contoh: Budi Santoso / PT Sukses Bersama" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5">Nomor WhatsApp Aktif *</label>
                                <input type="tel" name="phone" id="modal-phone" required placeholder="Contoh: 081234567890" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5">Email Bisnis *</label>
                                <input type="email" name="email" id="modal-email" required placeholder="nama@perusahaan.com" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5">Kategori Website</label>
                                <select name="service" id="modal-service" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 text-xs sm:text-sm text-slate-900 outline-none transition-colors">
                                    <option value="Company Profile">Company Profile &amp; Korporat</option>
                                    <option value="E-Commerce">E-Commerce &amp; Toko Online</option>
                                    <option value="Web Application / SaaS">Web Application &amp; SaaS Kustom</option>
                                    <option value="Landing Page">High-Conversion Landing Page</option>
                                    <option value="Redesign Website">Redesign &amp; Optimasi Kecepatan</option>
                                    <option value="Custom Project">Proyek Khusus Lainnya</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5">Estimasi Budget</label>
                                <select name="budget" id="modal-budget" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 text-xs sm:text-sm text-slate-900 outline-none transition-colors">
                                    <option value="< Rp 3.000.000">&lt; Rp 3.000.000</option>
                                    <option value="Rp 3.000.000 - Rp 7.000.000">Rp 3jt - Rp 7jt</option>
                                    <option value="Rp 7.000.000 - Rp 15.000.000">Rp 7jt - Rp 15jt</option>
                                    <option value="> Rp 15.000.000">&gt; Rp 15.000.000</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1.5">Kebutuhan Proyek / Fitur yang Diinginkan *</label>
                            <textarea name="message" id="modal-message" rows="4" required placeholder="Jelaskan kebutuhan website Anda, contoh fitur yang diinginkan, atau referensi website yang Anda sukai..." class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"></textarea>
                        </div>

                        <div class="pt-2 flex flex-col sm:flex-row gap-2.5 sm:gap-3">
                            <button type="button" onclick="sendFormToWhatsApp()" class="flex-1 py-3 sm:py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all">
                                <i class="fa-brands fa-whatsapp text-lg"></i>
                                <span>Kirim Langsung ke WhatsApp</span>
                            </button>
                            <button type="submit" id="modal-submit-btn" class="flex-1 py-3 sm:py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all">
                                <i class="fa-solid fa-paper-plane text-xs"></i>
                                <span>Kirim via Email</span>
                            </button>
                        </div>
                    </form>

                    <p class="text-[11px] text-slate-500 text-center mt-4">
                        🔒 Kerahasiaan data dan hak cipta ide proyek Anda terjamin aman bersama Soutprint.In.
                    </p>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/pages/contact.blade.php ENDPATH**/ ?>