<?php $__env->startSection('title', 'Portofolio & Showcase Website — Soutprint.In'); ?>
<?php $__env->startSection('meta_description', 'Lebih dari 1,000 pelanggan telah mempercayakan kebutuhan digital kepada Soutprint.In. Koleksi website aktif termasuk tadari.co.id, asy-syaakiriin.com, dan berbagai industri.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Portfolio Header (Sesuai Persis Teks & Desain Gambar Referensi 1) -->
    <section class="py-14 md:py-20 bg-white border-b border-slate-200 relative overflow-hidden">
        <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute inset-0 bg-mesh-portfolio"></div>
            <div class="absolute -top-16 right-1/4 w-[500px] h-[300px] bg-indigo-500/12 rounded-full blur-[100px]"></div>
            <div class="absolute top-1/4 -left-10 w-[450px] h-[300px] bg-cyan-400/12 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <h1 class="text-2xl min-[400px]:text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight font-heading leading-tight max-w-4xl">
                Lebih dari <span class="text-indigo-600 font-extrabold">1,000 pelanggan</span> telah mempercayakan kebutuhan digital mereka kepada kami.
            </h1>
            <p class="mt-4 sm:mt-5 text-sm sm:text-base md:text-lg text-slate-600 max-w-4xl leading-relaxed">
                Kami bangga telah bekerja sama dengan berbagai jenis bisnis, mulai dari startup, perusahaan kecil-menengah, hingga korporasi besar di berbagai industri. Dengan solusi yang disesuaikan dan layanan profesional, kami membantu klien kami mencapai efisiensi dan pertumbuhan yang signifikan.
            </p>
        </div>
    </section>

    <!-- Gallery Grid 10 Website (5 Kolom sesuai Gambar 1) -->
    <?php echo $__env->make('components.portfolio', ['hideHeader' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Order CTA -->
    <section class="py-12 sm:py-16 bg-white border-t border-slate-200 text-center">
        <div class="max-w-4xl mx-auto px-4">
            <h3 class="text-xl min-[400px]:text-2xl sm:text-3xl font-bold text-slate-900 font-heading">Tertarik membuat website dengan standar seperti di atas?</h3>
            <p class="text-xs sm:text-sm text-slate-600 mt-2">Hubungi kami hari ini untuk konsultasi konsep, anggaran, dan timeline pengerjaan gratis.</p>
            <div class="mt-6 sm:mt-8 flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 max-w-md mx-auto sm:max-w-none">
                <button type="button" onclick="openContactModal('Halaman Portofolio')" class="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-md">
                    Mulai Proyek Anda
                </button>
                <a href="https://wa.me/6281234567890?text=Halo%20Soutprint.In,%20saya%20tertarik%20dengan%20portofolio%20website%20Anda" target="_blank" class="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 flex items-center justify-center gap-2">
                    <i class="fa-brands fa-whatsapp text-lg text-emerald-600"></i>
                    <span>Diskusi via WhatsApp</span>
                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/pages/portfolio.blade.php ENDPATH**/ ?>