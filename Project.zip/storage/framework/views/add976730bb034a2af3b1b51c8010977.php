<section id="faq" class="py-20 md:py-28 relative bg-white border-b border-slate-200 overflow-hidden">
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (Crystal Clear FAQ Readability) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer (Cyan / Indigo / Blue Ambient Field) -->
        <div class="absolute inset-0 bg-mesh-faq"></div>

        <!-- 2. Ambient Glow Spheres -->
        <div class="absolute top-10 left-1/3 w-[500px] h-[350px] bg-cyan-400/10 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/2 -right-16 w-[450px] h-[350px] bg-indigo-500/10 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-10 left-10 w-[500px] h-[300px] bg-blue-500/10 rounded-full blur-[100px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
    </div>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <?php if(!($hideHeader ?? false)): ?>
        <!-- Header -->
        <div class="text-center max-w-2xl mx-auto">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-50 border border-cyan-200 text-cyan-800 text-xs font-bold mb-3">
                <i class="fa-solid fa-circle-question text-cyan-600"></i>
                <span>Tanya Jawab</span>
            </div>
            <h2 class="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight font-heading">
                Frequently Asked <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-indigo-600">Questions</span>
            </h2>
            <p class="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                Jawaban transparan untuk pertanyaan yang paling sering diajukan sebelum memulai proyek bersama kami.
            </p>
        </div>
        <?php endif; ?>

        <!-- Accordion items -->
        <div class="<?php echo e(($hideHeader ?? false) ? 'mt-4' : 'mt-10 sm:mt-14'); ?> space-y-3 sm:space-y-4" id="faq-accordion">
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="faq-item rounded-2xl bg-[#FAFAFC] border border-slate-200 transition-colors shadow-xs">
                <button type="button" 
                        class="faq-toggle w-full px-4 sm:px-6 py-3.5 sm:py-5 text-left flex items-center justify-between gap-3 sm:gap-4 focus:outline-none"
                        aria-expanded="<?php echo e($index === 0 ? 'true' : 'false'); ?>">
                    <span class="text-sm sm:text-base font-bold text-slate-900 font-heading">
                        <?php echo e($f['question']); ?>

                    </span>
                    <span class="faq-icon w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500 flex-shrink-0 transition-transform <?php echo e($index === 0 ? 'rotate-180 text-indigo-600 border-indigo-200' : ''); ?>">
                        <i class="fa-solid fa-chevron-down text-xs"></i>
                    </span>
                </button>
                <div class="faq-content px-4 sm:px-6 pb-4 sm:pb-6 text-xs sm:text-sm text-slate-600 leading-relaxed <?php echo e($index === 0 ? 'block' : 'hidden'); ?>">
                    <?php echo e($f['answer']); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>
<?php /**PATH D:\Project\resources\views/components/faq.blade.php ENDPATH**/ ?>