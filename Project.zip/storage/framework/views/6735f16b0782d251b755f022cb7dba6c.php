<section id="proses" class="py-20 md:py-28 relative bg-white border-b border-slate-200 overflow-hidden">
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (Crystal Clear Step Readability) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer -->
        <div class="absolute inset-0 bg-mesh-workflow"></div>

        <!-- 2. Ambient Glow Spheres -->
        <div class="absolute top-10 left-1/4 w-[500px] h-[350px] bg-purple-500/12 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/3 -right-16 w-[450px] h-[350px] bg-cyan-400/12 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-10 left-1/3 w-[500px] h-[300px] bg-emerald-400/10 rounded-full blur-[100px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <?php if(!($hideHeader ?? false)): ?>
        <!-- Header -->
        <div class="text-center max-w-3xl mx-auto">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-3">
                <i class="fa-solid fa-list-check text-indigo-600"></i>
                <span>Standar Mutu Tinggi</span>
            </div>
            <h2 class="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight font-heading">
                Alur Kerja <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Development Profesional</span>
            </h2>
            <p class="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                Setiap baris kode dan elemen visual dikerjakan secara cermat dengan metodologi agile yang terukur, tepat waktu, dan bebas stres.
            </p>
        </div>
        <?php endif; ?>

        <!-- 4 Step Process Grid -->
        <div class="<?php echo e(($hideHeader ?? false) ? 'mt-4' : 'mt-12 sm:mt-16'); ?> grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 relative">
            
            <!-- Step 1 -->
            <div class="p-5 sm:p-6 rounded-2xl bg-[#FAFAFC] border border-slate-200 hover:border-indigo-400 hover:bg-white transition-all duration-300 relative group shadow-xs hover:shadow-lg">
                <div class="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center justify-center font-black font-heading text-lg mb-5 group-hover:scale-110 transition-transform">
                    01
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2 font-heading">Discovery & Strategi</h3>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Kami membedah target pasar, profil audiens, arsitektur informasi, serta target konversi bisnis Anda untuk menyusun roadmap website yang presisi.
                </p>
            </div>

            <!-- Step 2 -->
            <div class="p-5 sm:p-6 rounded-2xl bg-[#FAFAFC] border border-slate-200 hover:border-cyan-400 hover:bg-white transition-all duration-300 relative group shadow-xs hover:shadow-lg">
                <div class="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-700 border border-cyan-200 flex items-center justify-center font-black font-heading text-lg mb-5 group-hover:scale-110 transition-transform">
                    02
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2 font-heading">UI/UX &amp; Interactive Mockup</h3>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Pembuatan wireframe dan prototipe desain interaktif di Figma. Anda dapat meninjau tampilan desktop dan mobile sebelum proses coding dimulai.
                </p>
            </div>

            <!-- Step 3 -->
            <div class="p-5 sm:p-6 rounded-2xl bg-[#FAFAFC] border border-slate-200 hover:border-purple-400 hover:bg-white transition-all duration-300 relative group shadow-xs hover:shadow-lg">
                <div class="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 border border-purple-200 flex items-center justify-center font-black font-heading text-lg mb-5 group-hover:scale-110 transition-transform">
                    03
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2 font-heading">Full-Stack Development</h3>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Coding bersih menggunakan Laravel 12 modern, optimasi kecepatan, integrasi payment &amp; WhatsApp API, serta pengujian keamanan berlapis.
                </p>
            </div>

            <!-- Step 4 -->
            <div class="p-5 sm:p-6 rounded-2xl bg-[#FAFAFC] border border-slate-200 hover:border-emerald-400 hover:bg-white transition-all duration-300 relative group shadow-xs hover:shadow-lg">
                <div class="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center font-black font-heading text-lg mb-5 group-hover:scale-110 transition-transform">
                    04
                </div>
                <h3 class="text-lg font-bold text-slate-900 mb-2 font-heading">Peluncuran &amp; Training CMS</h3>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Deploy ke cloud hosting NVMe berkecepatan tinggi, setup domain &amp; SSL, training pengelolaan CMS untuk tim Anda, serta garansi 60 hari.
                </p>
            </div>

        </div>

    </div>
</section>
<?php /**PATH D:\Project\resources\views/components/workflow.blade.php ENDPATH**/ ?>