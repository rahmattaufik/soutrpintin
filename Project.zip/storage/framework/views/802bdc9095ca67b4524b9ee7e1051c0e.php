<!-- Modern Gradient Wave Pricing Cards Section (White Background with Elegant Wave Effect) -->
<section id="layanan" class="py-20 md:py-28 relative bg-[#FAFAFC] border-b border-slate-200/80 overflow-hidden">
    
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (Crystal Clear Text Readability) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer (Multi-color Soft Radial Field) -->
        <div class="absolute inset-0 bg-mesh-services"></div>

        <!-- 2. Ambient Glow Spheres -->
        <div class="absolute -top-24 left-1/2 -translate-x-1/2 w-[850px] h-[400px] bg-indigo-500/12 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/3 -right-20 w-[500px] h-[350px] bg-cyan-400/12 rounded-full blur-[110px]"></div>
        <div class="absolute bottom-10 left-10 w-[500px] h-[350px] bg-teal-400/10 rounded-full blur-[100px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <?php if(!($hideHeader ?? false)): ?>
        <!-- Section Header (Clean White / Dark Text) -->
        <div class="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-4 shadow-2xs">
                <i class="fa-solid fa-gem text-cyan-600"></i>
                <span class="tracking-wide">INVESTASI TRANSPARAN &amp; BERKELAS</span>
            </div>
            <h2 class="text-3xl sm:text-5xl font-black text-slate-900 tracking-tight font-heading leading-tight">
                Paket Layanan &amp; <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Pricing Transparan</span>
            </h2>
            <p class="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                Investasi cerdas untuk pertumbuhan bisnis jangka panjang. Tanpa biaya tersembunyi, kode 100% milik Anda, dan garansi penuh.
            </p>

            <!-- Value Guarantees Banner -->
            <div class="mt-6 sm:mt-8 inline-flex flex-wrap items-center justify-center gap-3 sm:gap-6 px-4 sm:px-6 py-2.5 rounded-2xl bg-white border border-slate-200/90 text-xs text-slate-700 font-medium shadow-xs max-w-full">
                <span class="inline-flex items-center gap-1.5 font-semibold text-slate-900">
                    <i class="fa-solid fa-circle-check text-emerald-500"></i> 100% Hak Milik Source Code
                </span>
                <span class="hidden sm:inline text-slate-300">•</span>
                <span class="inline-flex items-center gap-1.5 font-semibold text-slate-900">
                    <i class="fa-solid fa-circle-check text-emerald-500"></i> Garansi 60 Hari Bug-Free
                </span>
                <span class="hidden sm:inline text-slate-300">•</span>
                <span class="inline-flex items-center gap-1.5 font-semibold text-slate-900">
                    <i class="fa-solid fa-circle-check text-emerald-500"></i> Gratis Domain .com &amp; Cloud NVMe
                </span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Filter Category Tabs -->
        <div class="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none touch-scroll -mx-4 px-4 sm:mx-0 sm:px-0 mb-8 sm:mb-14">
            <button type="button" onclick="filterServices('all')" class="service-tab-btn active px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-slate-900 text-white shadow-xs transition-all" data-category="all">
                Semua Paket (6)
            </button>
            <button type="button" onclick="filterServices('business')" class="service-tab-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-indigo-300 transition-all" data-category="business">
                Company Profile &amp; Landing Page
            </button>
            <button type="button" onclick="filterServices('app')" class="service-tab-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-indigo-300 transition-all" data-category="app">
                Toko Online &amp; Web Application
            </button>
            <button type="button" onclick="filterServices('care')" class="service-tab-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-indigo-300 transition-all" data-category="care">
                Redesign &amp; Maintenance
            </button>
        </div>

        <!-- 6 Gradient Wave Pricing Cards Grid (Retained Dark Body & Gradient Tops) -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 items-stretch" id="services-grid">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Distinct Color Profiles directly inspired by the user's reference image
                $profiles = [
                    'company-profile' => [
                        'tier' => 'BASIC',
                        'gradient' => 'bg-gradient-to-br from-[#E02874] via-[#C2185B] to-[#7B1FA2]',
                        'stars' => 5,
                        'accent_text' => 'text-pink-400',
                        'check_badge' => 'bg-pink-500/20 text-pink-300 border border-pink-500/40',
                        'btn_class' => 'border-2 border-pink-500 text-pink-300 hover:bg-gradient-to-r hover:from-pink-600 hover:to-purple-700 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(236,72,153,0.45)]',
                        'category' => 'business',
                    ],
                    'ecommerce' => [
                        'tier' => 'STANDARD',
                        'gradient' => 'bg-gradient-to-br from-[#00D09C] via-[#00B4B6] to-[#007B99]',
                        'stars' => 5,
                        'accent_text' => 'text-teal-300',
                        'check_badge' => 'bg-teal-500/20 text-teal-300 border border-teal-500/40',
                        'btn_class' => 'border-2 border-teal-400 text-teal-300 hover:bg-gradient-to-r hover:from-emerald-500 hover:to-teal-600 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(20,184,166,0.45)]',
                        'category' => 'app',
                    ],
                    'web-app' => [
                        'tier' => 'PREMIUM',
                        'gradient' => 'bg-gradient-to-br from-[#FBBF24] via-[#F59E0B] to-[#D97706]',
                        'stars' => 5,
                        'accent_text' => 'text-amber-400',
                        'check_badge' => 'bg-amber-500/20 text-amber-300 border border-amber-500/40',
                        'btn_class' => 'border-2 border-amber-400 text-amber-300 hover:bg-gradient-to-r hover:from-amber-500 hover:to-orange-600 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(245,158,11,0.45)]',
                        'category' => 'app',
                    ],
                    'landing-page' => [
                        'tier' => 'FAST TRACK',
                        'gradient' => 'bg-gradient-to-br from-[#3B82F6] via-[#2563EB] to-[#1D4ED8]',
                        'stars' => 4,
                        'accent_text' => 'text-blue-400',
                        'check_badge' => 'bg-blue-500/20 text-blue-300 border border-blue-500/40',
                        'btn_class' => 'border-2 border-blue-400 text-blue-300 hover:bg-gradient-to-r hover:from-blue-500 hover:to-indigo-600 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(59,130,246,0.45)]',
                        'category' => 'business',
                    ],
                    'redesign-optimization' => [
                        'tier' => 'BOOST 95+',
                        'gradient' => 'bg-gradient-to-br from-[#06B6D4] via-[#0891B2] to-[#0E7490]',
                        'stars' => 5,
                        'accent_text' => 'text-cyan-400',
                        'check_badge' => 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40',
                        'btn_class' => 'border-2 border-cyan-400 text-cyan-300 hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-600 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(6,182,212,0.45)]',
                        'category' => 'care',
                    ],
                    'maintenance-cloud' => [
                        'tier' => 'CARE 24/7',
                        'gradient' => 'bg-gradient-to-br from-[#8B5CF6] via-[#7C3AED] to-[#6D28D9]',
                        'stars' => 5,
                        'accent_text' => 'text-purple-400',
                        'check_badge' => 'bg-purple-500/20 text-purple-300 border border-purple-500/40',
                        'btn_class' => 'border-2 border-purple-400 text-purple-300 hover:bg-gradient-to-r hover:from-purple-500 hover:to-indigo-600 hover:text-white hover:border-transparent hover:shadow-[0_0_25px_rgba(139,92,246,0.45)]',
                        'category' => 'care',
                    ],
                ];

                $cfg = $profiles[$s['id']] ?? $profiles['company-profile'];
            ?>

            <div class="service-card group relative rounded-[32px] overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-2.5 shadow-[0_15px_35px_rgba(15,23,42,0.12)] hover:shadow-[0_25px_55px_rgba(15,23,42,0.25)] bg-[#13151F]"
                data-category="<?php echo e($cfg['category']); ?>">
                
                <!-- TOP HEADER WITH VIBRANT GRADIENT & ORGANIC WAVE -->
                <div class="relative pt-6 sm:pt-8 pb-10 sm:pb-12 px-4 sm:px-6 text-center overflow-hidden <?php echo e($cfg['gradient']); ?>">
                    
                    <!-- Tier Label -->
                    <span class="text-xs font-black uppercase tracking-widest text-slate-950/90 drop-shadow-2xs block">
                        <?php echo e($cfg['tier']); ?>

                    </span>

                    <!-- Package Name -->
                    <h3 class="text-base sm:text-lg font-black text-slate-950 font-heading mt-1 leading-snug drop-shadow-2xs">
                        <?php echo e($s['title']); ?>

                    </h3>

                    <!-- 5 Stars Rating -->
                    <div class="flex items-center justify-center gap-1 my-2 text-slate-950/80">
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <i class="fa-solid fa-star text-[11px] <?php echo e($i < $cfg['stars'] ? 'text-amber-300 drop-shadow-xs' : 'text-slate-900/30'); ?>"></i>
                        <?php endfor; ?>
                    </div>

                    <!-- Prominent Price Typography -->
                    <div class="mt-2 mb-0.5">
                        <span class="text-2xl min-[380px]:text-3xl sm:text-4xl font-black font-heading text-slate-950 tracking-tight drop-shadow-xs">
                            <?php echo e($s['starting_price']); ?>

                        </span>
                    </div>

                    <!-- Pricing Subtitle -->
                    <span class="text-[11px] font-extrabold uppercase tracking-wider text-slate-950/80 block">
                        <?php echo e(str_contains($s['starting_price'], '/bln') ? 'BIAYA PER BULAN' : 'INVESTASI PROYEK'); ?>

                    </span>

                    <!-- The Organic Wave SVG Transition to Dark Body -->
                    <div class="absolute inset-x-0 -bottom-[1px] leading-none overflow-hidden pointer-events-none select-none">
                        <svg class="w-full h-8 sm:h-10 block text-[#13151F]" viewBox="0 0 350 40" fill="none" preserveAspectRatio="none">
                            <!-- Subtle Shadow Curve Behind -->
                            <path d="M0,18 C110,42 240,-4 350,22 L350,40 L0,40 Z" fill="#000000" opacity="0.35"></path>
                            <!-- Solid Dark Body Wave -->
                            <path d="M0,14 C120,38 230,2 350,26 L350,40 L0,40 Z" fill="currentColor"></path>
                        </svg>
                    </div>
                </div>

                <!-- DARK CARD BODY (Matching User Image Reference) -->
                <div class="p-5 sm:p-7 flex-grow flex flex-col justify-between rounded-b-[32px] border-x border-b border-slate-800/80 bg-[#13151F]">
                    
                    <!-- Checklist Features -->
                    <div class="space-y-4 mb-6 sm:mb-8">
                        <div class="flex items-center justify-between pb-3 border-b border-slate-800/80">
                            <span class="text-[11px] font-extrabold uppercase tracking-wider text-slate-400">
                                Fitur &amp; Spesifikasi:
                            </span>
                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                                <?php echo e($s['badge']); ?>

                            </span>
                        </div>

                        <ul class="space-y-2.5 sm:space-y-3">
                            <?php $__currentLoopData = $s['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-start gap-2.5 sm:gap-3 text-xs sm:text-[13px] text-slate-200">
                                <span class="w-4.5 h-4.5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 text-[10px] <?php echo e($cfg['check_badge']); ?>">
                                    <i class="fa-solid fa-check"></i>
                                </span>
                                <span class="leading-relaxed font-medium"><?php echo e($f); ?></span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <!-- Pill Button with Glowing Outline (BUY NOW Style) -->
                    <div class="pt-4 sm:pt-5 border-t border-slate-800/80">
                        <button type="button" 
                                onclick="openContactModal('Pilih Paket: <?php echo e($s['title']); ?>')" 
                                class="w-full py-3 sm:py-3.5 px-4 sm:px-6 rounded-full font-black text-xs sm:text-sm tracking-wider uppercase transition-all duration-300 shadow-md flex items-center justify-center gap-2 group/btn <?php echo e($cfg['btn_class']); ?>">
                            <span>KONSULTASIKAN SEKARANG</span>
                            <i class="fa-solid fa-arrow-right text-xs group-hover/btn:translate-x-1 transition-transform"></i>
                        </button>
                    </div>

                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<!-- Filter Script -->
<script>
function filterServices(category) {
    const cards = document.querySelectorAll('.service-card');
    const buttons = document.querySelectorAll('.service-tab-btn');

    // Update Tab Buttons
    buttons.forEach(btn => {
        if (btn.getAttribute('data-category') === category) {
            btn.classList.add('bg-slate-900', 'text-white', 'active');
            btn.classList.remove('bg-white', 'text-slate-600');
        } else {
            btn.classList.remove('bg-slate-900', 'text-white', 'active');
            btn.classList.add('bg-white', 'text-slate-600');
        }
    });

    // Filter Cards with Animation
    cards.forEach(card => {
        const cardCat = card.getAttribute('data-category');
        if (category === 'all' || cardCat === category) {
            card.style.display = 'flex';
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>
<?php /**PATH D:\Project\resources\views/components/services.blade.php ENDPATH**/ ?>