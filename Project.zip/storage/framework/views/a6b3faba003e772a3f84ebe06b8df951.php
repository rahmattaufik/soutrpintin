<section class="py-20 md:py-28 relative bg-[#FAFAFC] border-b border-slate-200 overflow-hidden">
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (Crystal Clear Testimonial Readability) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer (Warm Amber / Rose / Violet Ambient Field) -->
        <div class="absolute inset-0 bg-mesh-testimonials"></div>

        <!-- 2. Ambient Glow Spheres -->
        <div class="absolute top-10 left-1/4 w-[500px] h-[350px] bg-amber-400/10 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/3 -right-16 w-[450px] h-[350px] bg-rose-400/10 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-10 left-1/3 w-[500px] h-[300px] bg-purple-400/10 rounded-full blur-[100px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <!-- Header -->
        <div class="text-center max-w-3xl mx-auto">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold mb-3">
                <i class="fa-solid fa-star text-amber-500"></i>
                <span>Kepuasan 99.8% Klien</span>
            </div>
            <h2 class="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight font-heading">
                Apa Kata Mereka Tentang <span class="text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600">Soutprint.In</span>
            </h2>
            <p class="mt-4 text-slate-600 text-sm sm:text-base leading-relaxed">
                Cerita sukses nyata dari para pemilik bisnis, founder, dan direktur perusahaan yang telah mempercayakan kehadiran digital mereka kepada kami.
            </p>
        </div>

        <!-- Testimonials Grid -->
        <div class="mt-10 sm:mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-5 sm:p-8 rounded-2xl bg-white border border-slate-200 hover:border-amber-400 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
                <div>
                    <!-- Star Rating -->
                    <div class="flex items-center gap-1 text-amber-400 text-sm mb-4">
                        <?php for($i = 0; $i < $t['rating']; $i++): ?>
                            <i class="fa-solid fa-star"></i>
                        <?php endfor; ?>
                        <span class="text-xs text-slate-500 ml-2 font-mono font-bold">5.0 / 5.0</span>
                    </div>

                    <!-- Quote -->
                    <p class="text-sm text-slate-700 italic leading-relaxed mb-6">
                        "<?php echo e($t['content']); ?>"
                    </p>
                </div>

                <!-- Client Info -->
                <div class="pt-5 border-t border-slate-100 flex items-center gap-3">
                    <div class="w-11 h-11 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center font-bold text-white text-sm shadow-md">
                        <?php echo e($t['avatar']); ?>

                    </div>
                    <div>
                        <h4 class="text-sm font-bold text-slate-900"><?php echo e($t['name']); ?></h4>
                        <p class="text-xs text-slate-500"><?php echo e($t['role']); ?></p>
                        <p class="text-[11px] text-indigo-600 font-bold"><?php echo e($t['company']); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>
<?php /**PATH D:\Project\resources\views/components/testimonials.blade.php ENDPATH**/ ?>