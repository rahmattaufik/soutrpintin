<?php $__env->startSection('title', 'Tanya Jawab (FAQ) — Soutprint.In'); ?>
<?php $__env->startSection('meta_description', 'Pertanyaan yang sering diajukan mengenai jasa pembuatan website, garansi, domain hosting, dan proses kerja sama di Soutprint.In.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- FAQ Header -->
    <section class="py-12 sm:py-16 md:py-20 bg-white border-b border-slate-200 relative overflow-hidden">
        <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute inset-0 bg-mesh-faq"></div>
            <div class="absolute -top-16 left-1/4 w-[500px] h-[300px] bg-cyan-400/12 rounded-full blur-[100px]"></div>
            <div class="absolute top-1/4 -right-10 w-[450px] h-[300px] bg-indigo-500/12 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-50 border border-cyan-200 text-cyan-800 text-xs font-bold mb-4">
                <i class="fa-solid fa-circle-question text-cyan-600"></i>
                <span>Pusat Bantuan &amp; Informasi</span>
            </div>
            <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight font-heading">
                Frequently Asked <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-indigo-600">Questions</span>
            </h1>
            <p class="mt-4 text-sm sm:text-base md:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
                Temukan jawaban lengkap dan transparan seputar proses pembuatan website, sistem pembayaran, domain, dan garansi.
            </p>
        </div>
    </section>

    <!-- FAQ Accordion Component -->
    <?php echo $__env->make('components.faq', ['hideHeader' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/pages/faq.blade.php ENDPATH**/ ?>