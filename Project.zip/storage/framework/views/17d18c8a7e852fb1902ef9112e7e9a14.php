<?php $__env->startSection('title', 'Alur Kerja & Standar Kualitas — Soutprint.In'); ?>
<?php $__env->startSection('meta_description', 'Pelajari alur metodologi pengembangan website dan standar kualitas rekayasa digital profesional di Soutprint.In.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- About Header -->
    <section class="py-16 md:py-20 bg-white border-b border-slate-200 relative overflow-hidden">
        <!-- Page Wave Effect: Big Bold Emerald Infinity S-Curve Wave (Filled + 5px Crest) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <svg class="w-full h-full" viewBox="0 0 1440 320" fill="none" preserveAspectRatio="none">
                <defs>
                    <linearGradient id="pageAboutWaveFill" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stop-color="#10B981" stop-opacity="0.14" />
                        <stop offset="50%" stop-color="#4F46E5" stop-opacity="0.18" />
                        <stop offset="100%" stop-color="#06B6D4" stop-opacity="0.12" />
                    </linearGradient>
                    <linearGradient id="pageAboutWave" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stop-color="#10B981" stop-opacity="0.85" />
                        <stop offset="50%" stop-color="#4F46E5" stop-opacity="0.95" />
                        <stop offset="100%" stop-color="#06B6D4" stop-opacity="0.85" />
                    </linearGradient>
                </defs>
                <!-- Large Filled Wave Body -->
                <path d="M0,140 C320,50 640,260 960,130 C1220,40 1360,200 1440,120 L1440,320 L0,320 Z" fill="url(#pageAboutWaveFill)"></path>
                <!-- Bold Thick 5px Crest Line -->
                <path d="M0,140 C320,50 640,260 960,130 C1220,40 1360,200 1440,120" stroke="url(#pageAboutWave)" stroke-width="5" fill="none"></path>
                <!-- Secondary 3px Dashed Wave -->
                <path d="M0,180 C340,90 660,300 980,170 C1240,80 1380,240 1440,160" stroke="url(#pageAboutWave)" stroke-width="3" stroke-dasharray="14 8" opacity="0.75" fill="none"></path>
            </svg>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-4">
                <i class="fa-solid fa-gem text-indigo-600"></i>
                <span>Dedikasi & Standar Rekayasa</span>
            </div>
            <h1 class="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight font-heading">
                Alur Kerja & <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Tentang Soutprint.In</span>
            </h1>
            <p class="mt-4 text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
                Kami adalah studio web development independen yang berdedikasi membangun produk web berkinerja tinggi, kode bersih, dan berorientasi pada hasil bisnis klien.
            </p>
        </div>
    </section>

    <!-- Workflow Component -->
    <?php echo $__env->make('components.workflow', ['hideHeader' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Values Grid -->
    <section class="py-16 bg-[#FAFAFC] border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-12">
                <h2 class="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">Prinsip Rekayasa Web Kami</h2>
                <p class="text-sm text-slate-600 mt-2">Fondasi yang memastikan website Anda dapat diandalkan dalam jangka panjang.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="p-8 rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-900 font-heading">Kecepatan Tanpa Kompromi</h3>
                    <p class="text-sm text-slate-600 mt-2 leading-relaxed">
                        Kami mengoptimalkan aset, database query, dan caching sehingga waktu muat halaman konsisten di bawah 1 detik untuk pengalaman pengguna terbaik.
                    </p>
                </div>

                <div class="p-8 rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-cyan-50 text-cyan-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-shield-check"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-900 font-heading">Keamanan Tingkat Lanjut</h3>
                    <p class="text-sm text-slate-600 mt-2 leading-relaxed">
                        Perlindungan terhadap SQL Injection, XSS, CSRF, dan brute-force attacks diterapkan secara berlapis pada setiap sistem yang kami buat.
                    </p>
                </div>

                <div class="p-8 rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-arrows-split-up-and-left"></i>
                    </div>
                    <h3 class="text-xl font-bold text-slate-900 font-heading">Skalabilitas & Kemudahan Rawat</h3>
                    <p class="text-sm text-slate-600 mt-2 leading-relaxed">
                        Kode terstruktur mengikuti pola MVC standar industri Laravel yang rapi, sehingga fitur dapat dikembangkan dengan mudah di masa depan.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <?php echo $__env->make('components.testimonials', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/pages/about.blade.php ENDPATH**/ ?>