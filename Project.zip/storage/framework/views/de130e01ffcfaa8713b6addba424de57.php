<?php $__env->startSection('title', 'Layanan Pembuatan Website — Soutprint.In'); ?>
<?php $__env->startSection('meta_description', 'Katalog lengkap layanan jasa pembuatan website profesional Soutprint.In: Company Profile, E-Commerce, Web Application & SaaS, Landing Page, dan Maintenance.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Services Page Header -->
    <section class="py-16 md:py-22 bg-white border-b border-slate-200 relative overflow-hidden">
        <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute inset-0 bg-mesh-services"></div>
            <div class="absolute -top-16 left-1/4 w-[500px] h-[300px] bg-indigo-500/12 rounded-full blur-[100px]"></div>
            <div class="absolute top-1/4 -right-10 w-[450px] h-[300px] bg-cyan-400/12 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-4">
                <i class="fa-solid fa-code text-indigo-600"></i>
                <span>Solusi Web Engineering Lengkap</span>
            </div>
            <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight font-heading">
                Layanan <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Pembuatan Website</span>
            </h1>
            <p class="mt-4 text-sm sm:text-base md:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
                Kami merancang arsitektur website yang kokoh, cepat, estetik, dan dirancang khusus untuk mencapai target pertumbuhan bisnis Anda.
            </p>
        </div>
    </section>

    <!-- Services Grid -->
    <?php echo $__env->make('components.services', ['hideHeader' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Standard Guarantees Included -->
    <section class="py-12 sm:py-16 bg-white border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-8 sm:mb-12">
                <h2 class="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">Setiap Paket Sudah Termasuk:</h2>
                <p class="text-xs sm:text-sm text-slate-600 mt-2">Standar kualitas tanpa biaya tersembunyi untuk seluruh klien Soutprint.In.</p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                <div class="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <div class="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-xl mx-auto mb-4">
                        <i class="fa-solid fa-globe"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-900">Gratis Domain 1 Tahun</h3>
                    <p class="text-xs text-slate-600 mt-2">Pilihan domain utama (.com, .id, atau .co.id) resmi berlisensi internasional.</p>
                </div>

                <div class="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <div class="w-12 h-12 rounded-xl bg-cyan-100 text-cyan-700 flex items-center justify-center text-xl mx-auto mb-4">
                        <i class="fa-solid fa-server"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-900">Cloud SSD NVMe Hosting</h3>
                    <p class="text-xs text-slate-600 mt-2">Server berkecepatan tinggi dengan uptime 99.9% dan bandwith stabil.</p>
                </div>

                <div class="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <div class="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl mx-auto mb-4">
                        <i class="fa-solid fa-lock"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-900">SSL Certificate (HTTPS)</h3>
                    <p class="text-xs text-slate-600 mt-2">Enkripsi keamanan data pengguna dan meningkatkan kepercayaan Google SEO.</p>
                </div>

                <div class="p-5 sm:p-6 rounded-2xl bg-slate-50 border border-slate-200 text-center">
                    <div class="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center text-xl mx-auto mb-4">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <h3 class="text-base font-bold text-slate-900">Garansi & Maintenance</h3>
                    <p class="text-xs text-slate-600 mt-2">Garansi perbaikan bug dan pendampingan teknis gratis selama 60 hari.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Consultation CTA -->
    <section class="py-12 sm:py-16 bg-[#FAFAFC]">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h3 class="text-xl min-[400px]:text-2xl sm:text-3xl font-bold text-slate-900 font-heading">Belum yakin paket mana yang tepat untuk bisnis Anda?</h3>
            <p class="text-xs sm:text-sm text-slate-600 mt-2">Konsultasikan ide Anda bersama technical lead kami untuk mendapatkan saran arsitektur terbaik.</p>
            <div class="mt-6 sm:mt-8 flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 max-w-md mx-auto sm:max-w-none">
                <button type="button" onclick="openContactModal('Halaman Layanan')" class="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-md">
                    Isi Formulir Kebutuhan
                </button>
                <a href="https://wa.me/6281234567890?text=Halo%20Soutprint.In,%20saya%20ingin%20tanya-tanya%20paket%20layanan%20website" target="_blank" class="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 flex items-center justify-center gap-2">
                    <i class="fa-brands fa-whatsapp text-lg text-emerald-600"></i>
                    <span>Tanya via WhatsApp</span>
                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/pages/services.blade.php ENDPATH**/ ?>