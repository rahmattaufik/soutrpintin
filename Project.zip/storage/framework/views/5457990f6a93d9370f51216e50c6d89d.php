<?php $__env->startSection('title', 'Soutprint.In — Jasa Pembuatan Website Profesional & Berkualitas'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <?php echo $__env->make('components.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Portfolio Showcase Section (Termasuk Tadari & Asy-Syaakiriin) -->
    <?php echo $__env->make('components.portfolio', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Layanan Pembuatan Website Section -->
    <?php echo $__env->make('components.services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Alur Kerja & Standar Mutu Section -->
    <?php echo $__env->make('components.workflow', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Review & Testimoni Section -->
    <?php echo $__env->make('components.testimonials', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- FAQ Section -->
    <?php echo $__env->make('components.faq', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\resources\views/home.blade.php ENDPATH**/ ?>