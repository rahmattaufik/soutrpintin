<header id="main-navbar" class="sticky top-0 z-40 transition-all duration-300 bg-white/95 backdrop-blur-xl border-b border-slate-200 shadow-xs">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16 sm:h-20">
            
            <!-- Brand Logo with logosoutprint.jpeg -->
            <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2.5 sm:gap-3 group shrink-0">
                <div class="relative w-9 h-9 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl overflow-hidden p-[1px] bg-gradient-to-tr from-cyan-500 to-indigo-600 shadow-[0_4px_12px_rgba(6,182,212,0.25)] group-hover:shadow-[0_6px_20px_rgba(6,182,212,0.4)] transition-all">
                    <img src="<?php echo e(asset('images/logosoutprint.jpeg')); ?>" alt="Logo Soutprint.In" class="w-full h-full object-cover rounded-[7px] sm:rounded-[10px]">
                </div>
                <div class="flex flex-col">
                    <span class="text-lg sm:text-xl font-black tracking-tight text-slate-900 font-heading">Soutprint<span class="text-indigo-600">.In</span></span>
                    <span class="text-[9px] sm:text-[10px] uppercase font-bold tracking-widest text-slate-500">Web Engineering Studio</span>
                </div>
            </a>

            <!-- Desktop Navigation Menu (Multi-Page Routes) -->
            <nav class="hidden lg:flex items-center gap-6 xl:gap-8 text-sm font-bold text-slate-600">
                <a href="<?php echo e(route('home')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('home') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    Beranda
                </a>
                <a href="<?php echo e(route('services')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('services') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    Layanan
                </a>
                <a href="<?php echo e(route('portfolio')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('portfolio') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    Portofolio
                </a>
                <a href="<?php echo e(route('about')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('about') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    Alur Kerja
                </a>
                <a href="<?php echo e(route('faq')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('faq') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    FAQ
                </a>
                <a href="<?php echo e(route('contact')); ?>" class="transition-colors py-1 relative hover:text-indigo-600 <?php echo e(request()->routeIs('contact') ? 'text-indigo-600 after:w-full after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0' : 'hover:after:w-full after:w-0 after:h-[2px] after:bg-indigo-600 after:absolute after:bottom-0 after:left-0 after:transition-all'); ?>">
                    Kontak
                </a>
            </nav>

            <!-- Desktop Action CTA Buttons -->
            <div class="hidden lg:flex items-center gap-3">
                <a href="<?php echo e(route('contact')); ?>" class="px-4 py-2.5 rounded-xl text-sm font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-all">
                    <i class="fa-solid fa-comments mr-1.5 text-indigo-600"></i> Diskusi Proyek
                </a>
                <button type="button" onclick="openContactModal('Navbar Konsultasi')" class="px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 shadow-[0_4px_15px_rgba(99,102,241,0.3)] hover:shadow-[0_6px_20px_rgba(99,102,241,0.45)] hover:scale-[1.02] active:scale-[0.98] transition-all">
                    <i class="fa-solid fa-headset mr-1.5"></i> Konsultasi Gratis
                </button>
            </div>

            <!-- Mobile Hamburger Button & Quick CTA -->
            <div class="flex lg:hidden items-center gap-2">
                <button type="button" onclick="openContactModal('Konsultasi Cepat Mobile')" class="px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 shadow-sm active:scale-95 transition-transform">
                    <span>Konsultasi</span>
                </button>
                <button id="mobile-menu-btn" type="button" class="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 flex items-center justify-center text-slate-700 hover:text-slate-900 focus:outline-none transition-colors" aria-label="Toggle menu" aria-expanded="false">
                    <i class="fa-solid fa-bars text-base sm:text-lg" id="menu-icon"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Drawer Menu (Multi-Page Routes) -->
    <div id="mobile-menu" class="hidden lg:hidden border-b border-slate-200 bg-white/98 backdrop-blur-xl px-4 sm:px-6 py-5 sm:py-6 shadow-xl transition-all duration-300">
        <div class="flex flex-col space-y-1 text-sm sm:text-base font-bold text-slate-700">
            <a href="<?php echo e(route('home')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('home') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Beranda</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
            <a href="<?php echo e(route('services')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('services') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Layanan Kami</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
            <a href="<?php echo e(route('portfolio')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('portfolio') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Portofolio &amp; Showcase</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
            <a href="<?php echo e(route('about')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('about') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Alur Kerja &amp; Standar</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
            <a href="<?php echo e(route('faq')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('faq') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Tanya Jawab (FAQ)</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
            <a href="<?php echo e(route('contact')); ?>" class="mobile-nav-link py-2.5 px-3 rounded-xl <?php echo e(request()->routeIs('contact') ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 hover:text-indigo-600'); ?> transition-colors flex items-center justify-between">
                <span>Kontak Kami</span>
                <i class="fa-solid fa-chevron-right text-xs text-slate-400"></i>
            </a>
        </div>

        <div class="pt-4 mt-2 border-t border-slate-200 flex flex-col gap-2.5">
            <button type="button" onclick="openContactModal('Konsultasi Drawer Mobile')" class="w-full py-3 rounded-xl text-center text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-cyan-500 shadow-md flex items-center justify-center gap-2">
                <i class="fa-brands fa-whatsapp text-lg text-white"></i>
                <span>Hubungi Konsultan Ahli</span>
            </button>
        </div>
    </div>
</header>
<?php /**PATH D:\Project\resources\views/components/navbar.blade.php ENDPATH**/ ?>