<section id="showcase" class="py-16 md:py-24 relative bg-[#FAFAFC] border-b border-slate-200 overflow-hidden">
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (Zero Text Obscurity) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer (Sapphire / Violet / Cyan Ambient Field) -->
        <div class="absolute inset-0 bg-mesh-portfolio"></div>

        <!-- 2. Ambient Glow Spheres -->
        <div class="absolute -top-20 right-10 w-[550px] h-[350px] bg-indigo-500/12 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/2 -left-20 w-[450px] h-[380px] bg-cyan-400/12 rounded-full blur-[120px]"></div>
        <div class="absolute -bottom-20 right-1/4 w-[500px] h-[300px] bg-purple-500/10 rounded-full blur-[110px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Fade Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <?php if(!($hideHeader ?? false)): ?>
        <!-- Header -->
        <div class="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-10 border-b border-slate-200">
            <div>
                <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-3">
                    <i class="fa-solid fa-trophy text-amber-500"></i>
                    <span>Showcase Hasil Karya</span>
                </div>
                <h2 class="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight font-heading">
                    Tampilan <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-cyan-600">Website Portofolio</span>
                </h2>
                <p class="mt-3 text-slate-600 text-sm sm:text-base max-w-xl">
                    Koleksi desain dan tampilan website nyata yang telah kami bangun dengan standar performa tinggi, visual estetik, dan responsif di berbagai perangkat.
                </p>
            </div>

            <!-- Category Filter Tabs -->
            <div class="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none touch-scroll -mx-4 px-4 sm:mx-0 sm:px-0" id="portfolio-filter-tabs">
                <button type="button" data-filter="all" class="portfolio-filter-btn active-filter px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-indigo-600 text-white shadow-md transition-all">
                    Semua (<?php echo e(count($portfolios)); ?>)
                </button>
                <button type="button" data-filter="company-profile" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Company Profile
                </button>
                <button type="button" data-filter="ecommerce" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    E-Commerce
                </button>
                <button type="button" data-filter="web-app" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Web App & Properti
                </button>
                <button type="button" data-filter="landing-page" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Pendidikan / Landing Page
                </button>
            </div>
        </div>
        <?php else: ?>
        <!-- Filter Bar for Dedicated Page -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 mb-4 border-b border-slate-200">
            <span class="text-xs sm:text-sm font-bold text-slate-700 uppercase tracking-wider">
                Menampilkan <strong class="text-indigo-600 font-extrabold"><?php echo e(count($portfolios)); ?> Desain Website Klien</strong>
            </span>
            <div class="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none touch-scroll -mx-4 px-4 sm:mx-0 sm:px-0" id="portfolio-filter-tabs">
                <button type="button" data-filter="all" class="portfolio-filter-btn active-filter px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-indigo-600 text-white shadow-md transition-all">
                    Semua (<?php echo e(count($portfolios)); ?>)
                </button>
                <button type="button" data-filter="company-profile" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Company Profile
                </button>
                <button type="button" data-filter="ecommerce" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    E-Commerce
                </button>
                <button type="button" data-filter="web-app" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Web App & Properti
                </button>
                <button type="button" data-filter="landing-page" class="portfolio-filter-btn px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap bg-white text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 transition-all">
                    Pendidikan & Kursus
                </button>
            </div>
        </div>
        <?php endif; ?>

        <!-- Portfolio Cards Grid (Responsive 1 to 5 Kolom) -->
        <div class="mt-8 grid grid-cols-1 min-[420px]:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-5 lg:gap-6" id="portfolio-grid">
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="portfolio-card group rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 p-2.5 sm:p-3 shadow-xs hover:shadow-2xl transition-all duration-300 flex flex-col justify-between hover:-translate-y-1"
                 data-category="<?php echo e($p['category']); ?>">
                
                <!-- Browser Mockup Window Container -->
                <div class="rounded-xl overflow-hidden bg-slate-100 border border-slate-200/90 shadow-inner flex flex-col">
                    
                    <!-- Mini Browser Header (Chrome Dots + URL) -->
                    <div class="px-2.5 py-1.5 bg-slate-100/90 border-b border-slate-200/90 flex items-center justify-between gap-1.5 select-none">
                        <div class="flex items-center gap-1">
                            <span class="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                            <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        </div>
                        <div class="flex-1 max-w-[120px] px-1.5 py-0.5 rounded bg-white border border-slate-200/70 text-[9px] font-mono text-slate-500 truncate text-center">
                            <?php echo e(!empty($p['live_url']) ? parse_url($p['live_url'], PHP_URL_HOST) : strtolower(str_replace([' ', '.', '&', '-'], '', $p['client'])) . '.co.id'); ?>

                        </div>
                        <div class="w-2.5"></div>
                    </div>

                    <!-- Scrollable Website UI Mockup Image -->
                    <div class="relative aspect-[3/4] overflow-hidden bg-white">
                        <img src="<?php echo e(asset($p['image'])); ?>" 
                             alt="<?php echo e($p['title']); ?>" 
                             loading="lazy"
                             class="w-full h-full object-cover object-top group-hover:scale-[1.02] transition-transform duration-500 ease-out cursor-pointer"
                             onclick="openWebsitePreview('<?php echo e(asset($p['image'])); ?>', '<?php echo e(addslashes($p['title'])); ?>', '<?php echo e(addslashes($p['client'])); ?>', '<?php echo e(addslashes($p['summary'])); ?>', '<?php echo e($p['live_url'] ?? ''); ?>')">
                        
                        <!-- Hover Overlay with Action Buttons -->
                        <div class="absolute inset-0 bg-slate-950/65 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col items-center justify-center gap-2 p-3 text-center">
                            <button type="button" 
                                    onclick="openWebsitePreview('<?php echo e(asset($p['image'])); ?>', '<?php echo e(addslashes($p['title'])); ?>', '<?php echo e(addslashes($p['client'])); ?>', '<?php echo e(addslashes($p['summary'])); ?>', '<?php echo e($p['live_url'] ?? ''); ?>')"
                                    class="w-full max-w-[140px] px-3 py-2 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold shadow-md flex items-center justify-center gap-1.5 transition-transform hover:scale-105">
                                <i class="fa-solid fa-expand text-indigo-600 text-xs"></i>
                                <span>Lihat Desain</span>
                            </button>
                            
                            <?php if(!empty($p['live_url'])): ?>
                            <a href="<?php echo e($p['live_url']); ?>" 
                               target="_blank" 
                               rel="noopener noreferrer" 
                               class="w-full max-w-[140px] px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md flex items-center justify-center gap-1.5 transition-transform hover:scale-105">
                                <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                                <span>Kunjungi Web</span>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Clean Card Footer (No metric clutter as requested in Gambar 2) -->
                <div class="pt-2.5 pb-1 px-1 flex flex-col justify-between flex-grow">
                    <div>
                        <div class="flex items-center justify-between gap-1 mb-1">
                            <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-600 truncate">
                                <?php echo e($p['category_label']); ?>

                            </span>
                            <?php if(!empty($p['live_url'])): ?>
                            <span class="text-[9px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 shrink-0">
                                Aktif Online
                            </span>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-xs sm:text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-indigo-600 transition-colors font-heading" title="<?php echo e($p['title']); ?>">
                            <?php echo e($p['client']); ?>

                        </h3>
                    </div>

                    <?php if(!empty($p['live_url'])): ?>
                    <a href="<?php echo e($p['live_url']); ?>" target="_blank" rel="noopener noreferrer" class="mt-2 text-[10px] font-mono text-blue-600 hover:underline flex items-center gap-1 truncate">
                        <span><?php echo e($p['live_url']); ?></span>
                        <i class="fa-solid fa-arrow-up-right-from-square text-[8px]"></i>
                    </a>
                    <?php endif; ?>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Fullscreen Website Preview Modal -->
        <div id="website-preview-modal" class="fixed inset-0 z-50 hidden bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6">
            <div class="relative w-full max-w-4xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col text-slate-800">
                
                <!-- Modal Top Header -->
                <div class="px-4 sm:px-6 py-3 sm:py-4 bg-white border-b border-slate-200 flex items-center justify-between gap-3 sm:gap-4">
                    <div class="truncate">
                        <h4 id="preview-modal-title" class="text-sm sm:text-base md:text-lg font-bold text-slate-900 font-heading truncate"></h4>
                        <p id="preview-modal-client" class="text-[11px] sm:text-xs text-indigo-600 font-semibold truncate"></p>
                    </div>
                    <div class="flex items-center gap-2 sm:gap-3 shrink-0">
                        <a id="preview-modal-link" href="#" target="_blank" rel="noopener noreferrer" class="hidden px-3 sm:px-4 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-sm flex items-center gap-1.5 transition-colors">
                            <span class="hidden sm:inline">Kunjungi Website Live</span>
                            <span class="sm:hidden">Kunjungi Web</span>
                            <i class="fa-solid fa-arrow-up-right-from-square text-[9px] sm:text-[10px]"></i>
                        </a>
                        <button type="button" onclick="closeWebsitePreview()" class="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors" aria-label="Tutup preview">
                            <i class="fa-solid fa-xmark text-base sm:text-lg"></i>
                        </button>
                    </div>
                </div>

                <!-- Modal Image Scrollable Body -->
                <div class="flex-1 overflow-y-auto p-3 sm:p-6 bg-slate-50 text-center">
                    <p id="preview-modal-summary" class="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto mb-3 sm:mb-4 text-left sm:text-center leading-relaxed"></p>
                    <div class="rounded-xl overflow-hidden border border-slate-200 shadow-md bg-white max-w-2xl mx-auto">
                        <img id="preview-modal-img" src="" alt="Preview Tampilan Website" class="w-full h-auto block">
                    </div>
                </div>

            </div>
        </div>

        <!-- Bottom CTA banner -->
        <div class="mt-10 sm:mt-14 p-5 sm:p-8 rounded-2xl bg-gradient-to-r from-indigo-50 via-purple-50 to-blue-50 border border-indigo-100 flex flex-col md:flex-row items-center justify-between gap-5 sm:gap-6 shadow-xs text-center md:text-left">
            <div>
                <h3 class="text-lg sm:text-xl md:text-2xl font-bold text-slate-900 font-heading">Ingin Website Bisnis Anda Tampil Modern Seperti di Atas?</h3>
                <p class="text-xs sm:text-sm text-slate-600 mt-1">Konsultasikan kebutuhan pembuatan website Anda bersama technical lead kami gratis tanpa komitmen.</p>
            </div>
            <button type="button" onclick="openContactModal('Showcase Banner Konsultasi')" class="w-full md:w-auto px-5 sm:px-6 py-3 sm:py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/30 whitespace-nowrap flex items-center justify-center gap-2 transition-all">
                <i class="fa-brands fa-whatsapp text-white text-base"></i>
                <span>Konsultasi Proyek Sekarang</span>
            </button>
        </div>

    </div>
</section>
<?php /**PATH D:\Project\resources\views/components/portfolio.blade.php ENDPATH**/ ?>