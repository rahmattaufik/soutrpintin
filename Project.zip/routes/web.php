<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/layanan', [HomeController::class, 'services'])->name('services');
Route::get('/portofolio', [HomeController::class, 'portfolio'])->name('portfolio');
Route::get('/alur-kerja', [HomeController::class, 'about'])->name('about');
Route::get('/faq', [HomeController::class, 'faq'])->name('faq');
Route::get('/kontak', [HomeController::class, 'contact'])->name('contact');

Route::post('/contact', [HomeController::class, 'submitContact'])->name('contact.submit');
