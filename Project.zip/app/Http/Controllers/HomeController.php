<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    private function getServicesData()
    {
        return [
            [
                'id' => 'company-profile',
                'title' => 'Company Profile & Korporat',
                'badge' => 'Paling Populer',
                'icon' => 'building-2',
                'description' => 'Membangun citra bisnis berkelas tinggi, kredibel, dan profesional untuk memenangkan kepercayaan klien dan investor besar.',
                'features' => [
                    'Desain Eksklusif Sesuai Brand Guidelines',
                    'Struktur SEO Lengkap & Terindeks Google',
                    'Fitur Multi-Bahasa (Indonesia & Inggris)',
                    'Integrasi Profil Perusahaan & Portofolio Interaktif',
                    'Dashboard CMS Mudah untuk Update Konten'
                ],
                'tech' => ['Laravel 12', 'Tailwind CSS', 'Alpine.js'],
                'starting_price' => 'Rp 3.500.000',
            ],
            [
                'id' => 'ecommerce',
                'title' => 'E-Commerce & Toko Online',
                'badge' => 'High Conversion',
                'icon' => 'shopping-bag',
                'description' => 'Toko online bertenaga tinggi dengan sistem checkout cepat, terintegrasi payment gateway lokal dan kalkulasi ongkir otomatis.',
                'features' => [
                    'Integrasi Payment (Midtrans, Xendit, QRIS, VA)',
                    'Hitung Ongkir Real-time (JNE, SiCepat, J&T)',
                    'Manajemen Stok, Varian Produk & Diskon Kupon',
                    'Order Notifikasi Otomatis via WhatsApp & Email',
                    'Laporan Penjualan & Dashboard Analitik'
                ],
                'tech' => ['Laravel 12', 'MySQL', 'Payment API'],
                'starting_price' => 'Rp 6.000.000',
            ],
            [
                'id' => 'web-app',
                'title' => 'Web Application & SaaS Kustom',
                'badge' => 'Skala Enterprise',
                'icon' => 'cpu',
                'description' => 'Aplikasi berbasis web untuk otomasi proses bisnis, sistem manajemen internal (ERP/CRM), portal properti, atau platform SaaS.',
                'features' => [
                    'Arsitektur Database Terstruktur & Skalabel',
                    'Role & Permission Multi-Level Pengguna',
                    'Sistem Dashboard Interaktif & Ekspor Data (PDF/Excel)',
                    'API Terbuka untuk Integrasi Pihak Ketiga',
                    'Keamanan Enkripsi Berlapis & Backup Otomatis'
                ],
                'tech' => ['Laravel 12', 'Vue/React', 'Redis', 'PostgreSQL'],
                'starting_price' => 'Rp 9.500.000',
            ],
            [
                'id' => 'landing-page',
                'title' => 'High-Conversion Landing Page',
                'badge' => 'Cepat & Efektif',
                'icon' => 'zap',
                'description' => 'Halaman promosi fokus konversi tinggi yang dioptimalkan khusus untuk kampanye iklan Google Ads, TikTok Ads, dan Meta Ads.',
                'features' => [
                    'Loading Ultra Cepat (Sub-1 Second Speed)',
                    'Copywriting Berorientasi Penjualan (AIDA framework)',
                    'Lead Form Terkoneksi Langsung ke WhatsApp & CRM',
                    'Setup Tracking Pixel & Google Tag Manager',
                    'A/B Testing Ready & Mobile Optimized'
                ],
                'tech' => ['HTML5 / Blade', 'Tailwind', 'Micro-Interactions'],
                'starting_price' => 'Rp 2.000.000',
            ],
            [
                'id' => 'redesign-optimization',
                'title' => 'Web Redesign & Performance Boost',
                'badge' => 'Revitalisasi',
                'icon' => 'sparkles',
                'description' => 'Tingkatkan performa website lama Anda dengan tampilan modern, kecepatan loading maksimal, serta skor Google PageSpeed 95+.',
                'features' => [
                    'Modernisasi UI/UX Mengikuti Tren Terkini',
                    'Pembersihan Kode Lama & Kompresi Aset',
                    'Optimasi Core Web Vitals (LCP, FID, CLS)',
                    'Migrasi Server & Setup Cloudflare CDN',
                    'Perbaikan Struktur Responsif Mobile'
                ],
                'tech' => ['Core Web Vitals', 'Vite', 'Cloudflare CDN'],
                'starting_price' => 'Rp 2.800.000',
            ],
            [
                'id' => 'maintenance-cloud',
                'title' => 'Cloud Hosting & Maintenance Care',
                'badge' => '24/7 Peace of Mind',
                'icon' => 'shield-check',
                'description' => 'Layanan pemeliharaan teknis komprehensif, update keamanan, monitoring uptime, dan proteksi serangan siber tanpa henti.',
                'features' => [
                    'Uptime Monitoring 99.9% Real-time Alerts',
                    'Backup Data Harian & Disaster Recovery',
                    'Update Patch Keamanan & Firewall Anti-DDoS',
                    'Bantuan Teknis Prioritas via WhatsApp Grup',
                    'Laporan Kinerja & SEO Bulanan'
                ],
                'tech' => ['AWS / VPS', 'SSL Certificate', 'Automated Backup'],
                'starting_price' => 'Rp 650.000/bln',
            ],
        ];
    }

    private function getPortfoliosData()
    {
        return [
            [
                'id' => 'tadari-property',
                'title' => 'TADARI — Properti & Sewa Apartemen',
                'client' => 'TADARI Indonesia',
                'category' => 'web-app',
                'category_label' => 'Properti & Real Estate',
                'year' => '2025',
                'image' => 'images/portfolio/tadari.png',
                'live_url' => 'http://tadari.co.id/',
                'summary' => 'Platform web properti modern untuk listing apartemen pilihan, formulir titip sewa/jual mandiri, artikel blog, dan profil tim agen.',
                'accent_color' => '#2563eb',
            ],
            [
                'id' => 'asy-syaakiriin',
                'title' => 'Yayasan & Masjid Asy-Syaakiriin',
                'client' => 'Yayasan Masjid Asy-Syaakiriin',
                'category' => 'company-profile',
                'category_label' => 'Portal Yayasan & Masjid',
                'year' => '2025',
                'image' => 'images/portfolio/asy-syaakiriin.png',
                'live_url' => 'http://asy-syaakiriin.com/',
                'summary' => 'Website resmi Yayasan & Masjid Asy-Syaakiriin untuk informasi kegiatan dakwah, transparansi kas masjid, dan jadwal kajian rutin.',
                'accent_color' => '#059669',
            ],
            [
                'id' => 'agung-megah-abadi',
                'title' => 'PT Agung Megah Abadi — Mining & Heavy Equipment',
                'client' => 'PT Agung Megah Abadi',
                'category' => 'company-profile',
                'category_label' => 'Pertambangan & Alat Berat',
                'year' => '2025',
                'image' => 'images/portfolio/mining.jpg',
                'live_url' => null,
                'summary' => 'Website profil korporasi tambang dan kontraktor alat berat nasional dengan katalog armada excavator dan proyek terintegrasi.',
                'accent_color' => '#16a34a',
            ],
            [
                'id' => 'global-language-academy',
                'title' => 'Global Language Academy — Kursus Bahasa Inggris',
                'client' => 'Global Language Academy',
                'category' => 'landing-page',
                'category_label' => 'Pendidikan & Akademi',
                'year' => '2025',
                'image' => 'images/portfolio/edu.jpg',
                'live_url' => null,
                'summary' => 'Website institusi pendidikan bahasa Inggris internasional dengan katalog kursus, jadwal kelas, dan portal pendaftaran online.',
                'accent_color' => '#0284c7',
            ],
            [
                'id' => 'fresh-harvest-organic',
                'title' => 'FreshHarvest — Sayur & Buah Organik Segar',
                'client' => 'FreshHarvest Indonesia',
                'category' => 'ecommerce',
                'category_label' => 'E-Commerce & Retail',
                'year' => '2025',
                'image' => 'images/portfolio/grocery.jpg',
                'live_url' => null,
                'summary' => 'Supermarket online buah dan sayur segar organik dengan keranjang belanja cepat, voucher diskon, dan pengiriman kilat.',
                'accent_color' => '#65a30d',
            ],
            [
                'id' => 'jaya-trans-shuttle',
                'title' => 'CV Jaya Trans — Rental Mobil & Travel HiAce',
                'client' => 'CV Jaya Trans Medan',
                'category' => 'company-profile',
                'category_label' => 'Transportasi & Rental',
                'year' => '2025',
                'image' => 'images/portfolio/rental.jpg',
                'live_url' => null,
                'summary' => 'Layanan sewa mobil HiAce Premio & Innova dengan tarif transparan, formulir reservasi rute, dan paket tur wisata Nusantara.',
                'accent_color' => '#0ea5e9',
            ],
            [
                'id' => 'peak-auto-solutions',
                'title' => 'Peak Auto Solutions — Dealer Truk 4x4 & SUV',
                'client' => 'Peak Auto Solutions',
                'category' => 'company-profile',
                'category_label' => 'Otomotif & Showroom',
                'year' => '2025',
                'image' => 'images/portfolio/automotive.jpg',
                'live_url' => null,
                'summary' => 'Showroom digital kendaraan off-road dan pikap tangguh dengan komparasi spesifikasi teknis dan simulasi kalkulator pembiayaan.',
                'accent_color' => '#1e293b',
            ],
            [
                'id' => 'alat-berat-nusantara',
                'title' => 'PT Alat Berat Nusantara — Excavator & Konstruksi',
                'client' => 'PT Alat Berat Nusantara',
                'category' => 'company-profile',
                'category_label' => 'Konstruksi & Alat Berat',
                'year' => '2025',
                'image' => 'images/portfolio/heavy-equipment.jpg',
                'live_url' => null,
                'summary' => 'Katalog sewa excavator hidrolik, bulldozer, dan crane konstruksi sipil dengan formulir penawaran quotation cepat.',
                'accent_color' => '#eab308',
            ],
            [
                'id' => 'dsp-law-firm',
                'title' => 'DSP Law Firm & Advocates — Advokat & Kantor Hukum',
                'client' => 'DSP Law Firm',
                'category' => 'company-profile',
                'category_label' => 'Hukum & Advokat',
                'year' => '2025',
                'image' => 'images/portfolio/lawfirm.jpg',
                'live_url' => null,
                'summary' => 'Kantor hukum korporat dan litigasi prestisius dengan cakupan area praktik hukum, profil mitra advokat, dan sesi konsultasi.',
                'accent_color' => '#d97706',
            ],
            [
                'id' => 'amanah-mina-tour',
                'title' => 'PT Amanah Mina Tour — Travel Haji & Umrah Resmi',
                'client' => 'PT Amanah Mina Tour',
                'category' => 'ecommerce',
                'category_label' => 'Biro Haji & Umrah',
                'year' => '2025',
                'image' => 'images/portfolio/umrah.jpg',
                'live_url' => null,
                'summary' => 'Biro perjalanan ibadah haji plus dan umrah berizin resmi Kemenag dengan paket hotel bintang 5 Mekkah-Madinah dan jadwal penerbangan.',
                'accent_color' => '#b45309',
            ],
        ];
    }

    private function getTestimonialsData()
    {
        return [
            [
                'name' => 'Bambang Soedirdjo',
                'role' => 'Chief Executive Officer',
                'company' => 'PT Astraea Energi Indonesia',
                'avatar' => 'BS',
                'content' => 'Soutprint.In berhasil mengubah total persepsi digital perusahaan kami. Website korporat baru kami dinilai sangat kredibel oleh calon investor internasional dan performanya sangat kencang!',
                'project' => 'Enterprise Holding Website',
                'rating' => 5,
            ],
            [
                'name' => 'Clarissa Gunawan',
                'role' => 'Founder & Creative Director',
                'company' => 'Valencia Haute Couture',
                'avatar' => 'CG',
                'content' => 'Toko online kami mengalami lonjakan konversi penjualan hingga 240% setelah di-develop oleh tim Soutprint.In. Desainnya sangat berkelas, navigasinya mulus di smartphone, dan checkout berjalan tanpa kendala.',
                'project' => 'Luxury E-Commerce',
                'rating' => 5,
            ],
            [
                'name' => 'Tim Pengelola Tadari',
                'role' => 'Direktur Properti',
                'company' => 'TADARI Indonesia (tadari.co.id)',
                'avatar' => 'TD',
                'content' => 'Pengembangan portal tadari.co.id dieksekusi dengan sangat rapi dan responsif. Pengunjung sangat mudah mencari apartemen dan submit formulir titip sewa atau jual.',
                'project' => 'Property Rental Platform',
                'rating' => 5,
            ],
        ];
    }

    private function getFaqsData()
    {
        return [
            [
                'question' => 'Berapa lama estimasi waktu pembuatan website di Soutprint.In?',
                'answer' => 'Tergantung pada kompleksitas proyek: Landing Page berkisar 3-5 hari kerja, Company Profile 7-14 hari kerja, E-commerce 14-25 hari kerja, dan Custom Web Application 3-6 minggu. Kami selalu menyertakan timeline terperinci di awal kontrak.',
            ],
            [
                'question' => 'Apakah website yang dibuat mudah dikelola sendiri tanpa latar belakang coding?',
                'answer' => 'Tentu saja! Kami membangun dashboard CMS yang sangat ramah pengguna (user-friendly). Anda bisa menambah produk, mengedit teks artikel, mengganti gambar, hingga memantau leads dengan mudah. Kami juga menyediakan sesi training gratis dan video panduan eksklusif.',
            ],
            [
                'question' => 'Bagaimana dengan domain (.com/.id) dan cloud hosting?',
                'answer' => 'Seluruh paket pembuatan website di Soutprint.In sudah termasuk gratis Domain pilihan (.com / .id / .co.id) selama 1 tahun, Cloud SSD NVMe Hosting berkecepatan tinggi, serta SSL Certificate (HTTPS) untuk enkripsi keamanan maksimal.',
            ],
            [
                'question' => 'Apakah website sudah dioptimalkan untuk SEO dan tampilan mobile?',
                'answer' => 'Ya, 100%. Kami menerapkan prinsip Mobile-First Design sehingga website tampil memukau di semua gadget (iPhone, Android, Tablet, Laptop). Struktur website juga telah disesuaikan dengan standar SEO on-page Google (meta tags, schema markup, sitemap.xml, dan kecepatan di atas rata-rata).',
            ],
            [
                'question' => 'Bagaimana sistem pembayaran dan pembagian terminnya?',
                'answer' => 'Sistem pembayaran sangat fleksibel dan aman: Uang muka (DP) 50% di awal kontrak, dan pelunasan 50% setelah website selesai diuji coba (UAT), disetujui, dan siap diluncurkan secara resmi.',
            ],
            [
                'question' => 'Apakah Soutprint.In memberikan garansi dan maintenance pasca rilis?',
                'answer' => 'Pasti. Setiap proyek mendapatkan garansi bebas bug & maintenance berkala gratis selama 30 hingga 90 hari setelah peluncuran. Kami juga menyediakan paket pemeliharaan berkelanjutan (Cloud Hosting Care) untuk backup dan update sistem rutin.',
            ],
        ];
    }

    // 1. Home Page
    public function index()
    {
        $services = $this->getServicesData();
        $portfolios = $this->getPortfoliosData();
        $testimonials = $this->getTestimonialsData();
        $faqs = array_slice($this->getFaqsData(), 0, 4);

        return view('home', compact('services', 'portfolios', 'testimonials', 'faqs'));
    }

    // 2. Layanan Page
    public function services()
    {
        $services = $this->getServicesData();
        return view('pages.services', compact('services'));
    }

    // 3. Portofolio Page
    public function portfolio()
    {
        $portfolios = $this->getPortfoliosData();
        return view('pages.portfolio', compact('portfolios'));
    }

    // 4. Tentang Kami / Alur Kerja Page
    public function about()
    {
        $testimonials = $this->getTestimonialsData();
        return view('pages.about', compact('testimonials'));
    }

    // 5. FAQ Page
    public function faq()
    {
        $faqs = $this->getFaqsData();
        return view('pages.faq', compact('faqs'));
    }

    // 6. Kontak Page
    public function contact()
    {
        return view('pages.contact');
    }

    // Submit Contact Handler
    public function submitContact(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email|max:150',
            'phone' => 'required|string|max:20',
            'service' => 'required|string',
            'budget' => 'nullable|string',
            'message' => 'required|string|max:2000',
        ]);

        if ($request->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Terima kasih! Tim konsultan Soutprint.In akan segera menghubungi Anda dalam waktu 1x24 jam.',
            ]);
        }

        return back()->with('success', 'Permintaan konsultasi Anda berhasil dikirim! Tim kami akan menghubungi melalui WhatsApp/Email segera.');
    }
}
