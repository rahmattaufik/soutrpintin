<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>@yield('title', 'Soutprint.In — Jasa Pembuatan Website, Showcase & Mockup Eksklusif')</title>
    <meta name="description" content="@yield('meta_description', 'Soutprint.In adalah studio web development profesional spesialis pembuatan website modern, company profile, e-commerce berkonversi tinggi, mockup interaktif, dan web app kustom.')">
    <meta name="keywords" content="jasa pembuatan website, web agency indonesia, mockup website interaktif, portofolio web developer, bikin website murah berkualitas, Soutprint, Soutprint.In">
    
    <!-- Open Graph / Meta Sosial -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="Soutprint.In — Modern Web Engineering & Creative Agency">
    <meta property="og:description" content="Wujudkan website profesional berkecepatan tinggi, SEO-ready, dan berstandar internasional bersama Soutprint.In.">
    <meta property="og:image" content="{{ asset('images/logosoutprint.jpeg') }}">
    <link rel="icon" type="image/jpeg" href="{{ asset('images/logosoutprint.jpeg') }}">

    <!-- Google Fonts: Plus Jakarta Sans & Outfit -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    @stack('styles')
</head>
<body class="bg-[#FAFAFC] text-slate-800 font-sans selection:bg-indigo-600 selection:text-white antialiased overflow-x-hidden min-h-screen flex flex-col">

    <!-- Ambient Glow Backgrounds (Soft Pastel on Light Canvas) -->
    <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div class="absolute -top-40 -left-40 w-96 md:w-[600px] h-96 md:h-[600px] bg-indigo-200/40 rounded-full blur-[120px]"></div>
        <div class="absolute top-1/3 -right-40 w-96 md:w-[600px] h-96 md:h-[600px] bg-cyan-200/35 rounded-full blur-[140px]"></div>
        <div class="absolute bottom-10 left-1/4 w-96 md:w-[500px] h-96 md:h-[500px] bg-purple-200/35 rounded-full blur-[130px]"></div>
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#00000006_1px,transparent_1px),linear-gradient(to_bottom,#00000006_1px,transparent_1px)] bg-[size:3.5rem_3.5rem]"></div>
        
        <!-- Ambient 3D Developer Elements in Background -->
        <div class="absolute top-[40%] -right-20 w-72 md:w-[420px] pointer-events-none opacity-[0.11] select-none animate-float hidden lg:block">
            <img src="{{ asset('images/developer-3d.png') }}" alt="" class="w-full h-auto">
        </div>
        <div class="absolute top-[75%] -left-16 w-72 md:w-[380px] pointer-events-none opacity-[0.09] select-none animate-float-delayed hidden lg:block">
            <img src="{{ asset('images/developer-3d-female.png') }}" alt="" class="w-full h-auto">
        </div>
    </div>

    <!-- Top Announcement Bar (Light Mode) -->
    <div class="relative z-50 bg-gradient-to-r from-indigo-50 via-purple-50 to-blue-50 border-b border-indigo-100 text-[11px] sm:text-xs py-1.5 sm:py-2 px-3 sm:px-4 text-center text-slate-700">
        <div class="max-w-7xl mx-auto flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap leading-relaxed">
            <span>Dapatkan <strong>Diskon Eksklusif 15%</strong> &amp; Gratis Hosting SSD NVMe 1 Tahun untuk 5 Klien Pertama Bulan Ini!</span>
            <a href="{{ route('contact') }}" class="underline hover:text-indigo-800 font-bold ml-1 text-indigo-700 inline-flex items-center gap-1">
                Klaim Sekarang <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
    </div>

    <!-- Navigation Header -->
    @include('components.navbar')

    <!-- Main Content -->
    <main class="relative z-10 flex-grow">
        @yield('content')
    </main>

    <!-- Marquee Technology Showcase (Tepat di Atas Footer) -->
    @include('components.marquee')

    <!-- Footer -->
    @include('components.footer')

    <!-- Interactive Contact & Consultation Modal -->
    @include('components.contact-modal')

    <!-- Floating Action Buttons (Back to Top & WhatsApp CTA) -->
    <div class="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex flex-col items-end gap-2.5 sm:gap-3 select-none">
        <!-- Floating Back to Top Button (Above WhatsApp Button) -->
        <button id="back-to-top-btn"
                type="button"
                onclick="window.scrollTo({top: 0, behavior: 'smooth'})"
                aria-label="Kembali ke atas"
                title="Kembali ke atas"
                class="group w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-slate-900/90 hover:bg-indigo-600 text-white border border-slate-700/80 hover:border-indigo-400 shadow-[0_8px_20px_rgba(0,0,0,0.3)] hover:shadow-indigo-500/30 hover:scale-110 active:scale-95 transition-all duration-300 flex items-center justify-center backdrop-blur-md opacity-0 pointer-events-none translate-y-3 mr-0.5 sm:mr-1">
            <i class="fa-solid fa-arrow-up text-xs sm:text-sm group-hover:-translate-y-0.5 transition-transform duration-200"></i>
        </button>

        <!-- WhatsApp CTA Group with Tooltip -->
        <div class="flex items-center gap-3">
            <!-- Floating notification bubble -->
            <div id="wa-tooltip" class="hidden md:flex items-center gap-2 bg-white text-xs text-slate-800 border border-slate-200 px-3.5 py-2 rounded-xl shadow-xl backdrop-blur-md animate-bounce font-medium">
                <span>Konsultasi online via WhatsApp</span>
            </div>
            
            <a href="https://wa.me/6281234567890?text=Halo%20Soutprint.In,%20saya%20tertarik%20untuk%20konsultasi%20pembuatan%20website" 
               target="_blank" 
               rel="noopener noreferrer" 
               aria-label="Konsultasi via WhatsApp" 
               class="group flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-emerald-500 to-green-500 text-white shadow-[0_10px_25px_rgba(16,185,129,0.35)] hover:shadow-[0_15px_30px_rgba(16,185,129,0.5)] hover:scale-110 active:scale-95 transition-all duration-300">
                <i class="fa-brands fa-whatsapp text-xl sm:text-2xl group-hover:rotate-12 transition-transform"></i>
            </a>
        </div>
    </div>

    <!-- Toast Notification Container -->
    <div id="toast-container" class="fixed top-16 sm:top-20 right-4 sm:right-6 z-50 flex flex-col gap-3 pointer-events-none max-w-[calc(100vw-2rem)] sm:max-w-md"></div>

    @stack('scripts')
</body>
</html>
