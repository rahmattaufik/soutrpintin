@extends('layouts.app')

@section('title', 'Soutprint.In — Jasa Pembuatan Website Profesional & Berkualitas')

@section('content')
    <!-- Hero Section -->
    @include('components.hero')

    <!-- Portfolio Showcase Section (Termasuk Tadari & Asy-Syaakiriin) -->
    @include('components.portfolio')

    <!-- Layanan Pembuatan Website Section -->
    @include('components.services')

    <!-- Alur Kerja & Standar Mutu Section -->
    @include('components.workflow')

    <!-- Review & Testimoni Section -->
    @include('components.testimonials')

    <!-- FAQ Section -->
    @include('components.faq')
@endsection
