@extends('layouts.app')

@section('title', 'Alur Kerja & Standar Kualitas — Soutprint.In')
@section('meta_description', 'Pelajari alur metodologi pengembangan website dan standar kualitas rekayasa digital profesional di Soutprint.In.')

@section('content')
    <!-- About Header -->
    <section class="py-16 md:py-20 bg-white border-b border-slate-200 relative overflow-hidden">
        <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable) -->
        <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
            <div class="absolute inset-0 bg-mesh-workflow"></div>
            <div class="absolute -top-16 left-1/4 w-[500px] h-[300px] bg-purple-500/12 rounded-full blur-[100px]"></div>
            <div class="absolute top-1/4 -right-10 w-[450px] h-[300px] bg-emerald-400/12 rounded-full blur-[110px]"></div>
            <div class="absolute inset-0 bg-grid-subtle mask-radial-wide"></div>
        </div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold mb-4">
                <i class="fa-solid fa-gem text-indigo-600"></i>
                <span>Dedikasi & Standar Rekayasa</span>
            </div>
            <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight font-heading">
                Alur Kerja &amp; <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">Tentang Soutprint.In</span>
            </h1>
            <p class="mt-4 text-sm sm:text-base md:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
                Kami adalah studio web development independen yang berdedikasi membangun produk web berkinerja tinggi, kode bersih, dan berorientasi pada hasil bisnis klien.
            </p>
        </div>
    </section>

    <!-- Workflow Component -->
    @include('components.workflow', ['hideHeader' => true])

    <!-- Values Grid -->
    <section class="py-12 sm:py-16 bg-[#FAFAFC] border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
                <h2 class="text-2xl sm:text-4xl font-extrabold text-slate-900 font-heading">Prinsip Rekayasa Web Kami</h2>
                <p class="text-xs sm:text-sm text-slate-600 mt-2">Fondasi yang memastikan website Anda dapat diandalkan dalam jangka panjang.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
                <div class="p-6 sm:p-8 rounded-2xl sm:rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 font-heading">Kecepatan Tanpa Kompromi</h3>
                    <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                        Kami mengoptimalkan aset, database query, dan caching sehingga waktu muat halaman konsisten di bawah 1 detik untuk pengalaman pengguna terbaik.
                    </p>
                </div>

                <div class="p-6 sm:p-8 rounded-2xl sm:rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-cyan-50 text-cyan-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-shield-check"></i>
                    </div>
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 font-heading">Keamanan Tingkat Lanjut</h3>
                    <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                        Perlindungan terhadap SQL Injection, XSS, CSRF, dan brute-force attacks diterapkan secara berlapis pada setiap sistem yang kami buat.
                    </p>
                </div>

                <div class="p-6 sm:p-8 rounded-2xl sm:rounded-3xl bg-white border border-slate-200 shadow-xs">
                    <div class="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl mb-5 font-bold">
                        <i class="fa-solid fa-arrows-split-up-and-left"></i>
                    </div>
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 font-heading">Skalabilitas &amp; Kemudahan Rawat</h3>
                    <p class="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                        Kode terstruktur mengikuti pola MVC standar industri Laravel yang rapi, sehingga fitur dapat dikembangkan dengan mudah di masa depan.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    @include('components.testimonials')
@endsection
