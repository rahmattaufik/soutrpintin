<section class="relative pt-10 pb-16 md:pt-16 md:pb-24 overflow-hidden bg-gradient-to-b from-slate-50/60 via-white to-slate-50/40 border-b border-slate-200/60">
    
    <!-- Modern Tech Background: Gradient Mesh + Ambient Glow + Grid tipis (100% Readable, Zero Text Clutter) -->
    <div class="absolute inset-0 pointer-events-none select-none overflow-hidden z-0">
        <!-- 1. Gradient Mesh Layer (Fluid Multi-color Radial Glows) -->
        <div class="absolute inset-0 bg-mesh-hero"></div>

        <!-- 2. Ambient Glow Spheres (Vibrant Soft Atmospheric Light) -->
        <div class="absolute -top-24 left-1/4 w-[500px] h-[350px] bg-indigo-500/15 rounded-full blur-[110px]"></div>
        <div class="absolute top-1/4 -right-16 w-[450px] h-[400px] bg-cyan-400/15 rounded-full blur-[120px]"></div>
        <div class="absolute bottom-10 left-1/3 w-[500px] h-[300px] bg-purple-400/12 rounded-full blur-[100px]"></div>

        <!-- 3. Grid Tipis (Thin Subtle Geometric Grid with Radial Fade Mask) -->
        <div class="absolute inset-0 bg-grid-subtle mask-radial-subtle"></div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <!-- 2-COLUMN SPLIT HERO GRID -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 xl:gap-12 items-center">
            
            <!-- LEFT COLUMN: Headlines, Subtitle & CTAs -->
            <div class="lg:col-span-7 text-center lg:text-left">
                <!-- Badge with logo -->
                <div class="inline-flex items-center gap-2 sm:gap-2.5 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-800 text-xs sm:text-sm font-bold mb-5 sm:mb-6 shadow-2xs max-w-full">
                    <img src="{{ asset('images/logosoutprint.jpeg') }}" alt="Logo" class="w-4.5 h-4.5 sm:w-5 sm:h-5 rounded-md object-cover shrink-0">
                    <span class="truncate sm:overflow-visible">
                        <span class="hidden sm:inline">Studio Pembuatan Website &amp; Digital Engineering Indonesia</span>
                        <span class="sm:hidden">Studio Pembuatan Website Modern</span>
                    </span>
                    <span class="text-slate-300">|</span>
                    <span class="text-slate-600 shrink-0">Soutprint.In</span>
                </div>

                <!-- Main Headline -->
                <h1 class="text-3xl min-[400px]:text-4xl sm:text-5xl lg:text-5xl xl:text-6xl font-black tracking-tight text-slate-900 leading-[1.2] sm:leading-[1.15] font-heading">
                    Wujudkan Website <br class="hidden sm:inline">
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600">
                        Modern Berkelas Dunia
                    </span>
                    <br>
                    dengan Konversi Nyata.
                </h1>

                <!-- Subtitle -->
                <p class="mt-4 sm:mt-5 text-sm sm:text-base md:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                    Tingkatkan kredibilitas dan omzet bisnis Anda bersama <strong class="text-slate-900 font-bold">Soutprint.In</strong>. Spesialis perancangan Company Profile berwibawa, Toko Online (E-Commerce) otomatis, hingga Web Application kustom berkecepatan kilat dan SEO-ready.
                </p>

                <!-- CTA Action Buttons -->
                <div class="mt-6 sm:mt-8 flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-3 sm:gap-3.5">
                    <a href="{{ route('portfolio') }}" class="w-full sm:w-auto px-6 sm:px-7 py-3 sm:py-3.5 rounded-xl text-xs sm:text-sm md:text-base font-bold text-white bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 shadow-[0_10px_25px_rgba(99,102,241,0.35)] hover:shadow-[0_15px_30px_rgba(99,102,241,0.5)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                        <i class="fa-solid fa-layer-group"></i>
                        <span>Lihat Portofolio</span>
                        <i class="fa-solid fa-arrow-right text-xs ml-1"></i>
                    </a>
                    
                    <a href="{{ route('services') }}" class="w-full sm:w-auto px-5 sm:px-6 py-3 sm:py-3.5 rounded-xl text-xs sm:text-sm md:text-base font-bold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 shadow-2xs hover:border-indigo-400 transition-all flex items-center justify-center gap-2">
                        <i class="fa-solid fa-grid-2 text-indigo-600"></i>
                        <span>Paket Layanan</span>
                    </a>

                    <button type="button" onclick="openContactModal('Hero Konsultasi Langsung')" class="w-full sm:w-auto px-5 sm:px-6 py-3 sm:py-3.5 rounded-xl text-xs sm:text-sm md:text-base font-bold text-emerald-800 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all flex items-center justify-center gap-2">
                        <i class="fa-brands fa-whatsapp text-lg text-emerald-600"></i>
                        <span>Konsultasi WA</span>
                    </button>
                </div>
            </div>

            <!-- RIGHT COLUMN: Dedicated 3D Developer Visual Showcase (No Overlap with Text) -->
            <div class="lg:col-span-5 flex justify-center items-center relative">
                <div class="relative w-full max-w-[280px] min-[400px]:max-w-[340px] sm:max-w-[420px] lg:max-w-none flex items-center justify-center py-2 sm:py-6">
                    
                    <!-- Ambient Backing Glow & Frame -->
                    <div class="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 via-purple-500/5 to-cyan-500/10 rounded-3xl blur-2xl -z-10"></div>
                    <div class="absolute -top-4 -right-4 w-28 sm:w-36 h-28 sm:h-36 bg-cyan-400/15 rounded-full blur-2xl -z-10"></div>
                    <div class="absolute -bottom-4 -left-4 w-28 sm:w-36 h-28 sm:h-36 bg-indigo-500/15 rounded-full blur-2xl -z-10"></div>

                    <!-- 3D Developer Illustration with Floating Motion -->
                    <div class="relative animate-float z-10 w-full max-w-[260px] min-[400px]:max-w-[320px] sm:max-w-[390px] xl:max-w-[430px]">
                        <img src="{{ asset('images/developer-3d.png') }}" 
                             alt="3D Web Developer Soutprint" 
                             class="w-full h-auto drop-shadow-[0_20px_40px_rgba(99,102,241,0.22)] select-none">
                    </div>
                </div>
            </div>

        </div>

        <!-- KEY TRUST METRICS -->
        <div class="mt-10 sm:mt-14 pt-6 sm:pt-8 border-t border-slate-200/80 grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 text-center">
            <div class="space-y-1 reveal-metric">
                <p class="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 font-heading">140+</p>
                <p class="text-[11px] sm:text-xs md:text-sm text-slate-500 font-semibold">Website Resmi Terbit</p>
            </div>
            <div class="space-y-1 reveal-metric reveal-delay-100">
                <p class="text-2xl sm:text-3xl md:text-4xl font-black text-indigo-600 font-heading">0.9s</p>
                <p class="text-[11px] sm:text-xs md:text-sm text-slate-500 font-semibold">Rata-rata Loading Speed</p>
            </div>
            <div class="space-y-1 reveal-metric reveal-delay-200">
                <p class="text-2xl sm:text-3xl md:text-4xl font-black text-cyan-600 font-heading">99.8%</p>
                <p class="text-[11px] sm:text-xs md:text-sm text-slate-500 font-semibold">Tingkat Kepuasan Klien</p>
            </div>
            <div class="space-y-1 reveal-metric reveal-delay-300">
                <p class="text-2xl sm:text-3xl md:text-4xl font-black text-amber-600 font-heading">100%</p>
                <p class="text-[11px] sm:text-xs md:text-sm text-slate-500 font-semibold">Garansi &amp; Maintenance</p>
            </div>
        </div>

        <!-- REAL CLIENT QUICK FEATURE CARDS (TADARI & Asy-Syaakiriin) - Clean Background, No Overlaps -->
        <div class="mt-10 sm:mt-12 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            
            <!-- Real Client Card 1: TADARI -->
            <div class="group p-5 sm:p-6 rounded-2xl bg-white border border-slate-200 hover:border-blue-500/60 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
                <div>
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors font-heading">
                        TADARI Indonesia
                    </h3>
                    <p class="text-xs font-mono text-slate-500 mt-0.5">http://tadari.co.id/</p>

                    <p class="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                        Platform manajemen properti dan pencarian apartemen, titip sewa/jual unit, informasi tim agen, serta blog berita properti terintegrasi.
                    </p>
                </div>

                <div class="mt-5 sm:mt-6 pt-4 border-t border-slate-100 flex items-center justify-end">
                    <a href="http://tadari.co.id/" target="_blank" rel="noopener noreferrer" class="px-3.5 sm:px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm flex items-center gap-1.5 transition-all">
                        <span>Kunjungi Website</span>
                        <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                    </a>
                </div>
            </div>

            <!-- Real Client Card 2: Asy-Syaakiriin -->
            <div class="group p-5 sm:p-6 rounded-2xl bg-white border border-slate-200 hover:border-emerald-500/60 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
                <div>
                    <h3 class="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-emerald-600 transition-colors font-heading">
                        Yayasan &amp; Masjid Asy-Syaakiriin
                    </h3>
                    <p class="text-xs font-mono text-slate-500 mt-0.5">http://asy-syaakiriin.com/</p>

                    <p class="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                        Website pusat informasi kegiatan dakwah, transparansi kas masjid, publikasi jadwal kajian, serta layanan jemaah berbasis web modern responsif.
                    </p>
                </div>

                <div class="mt-5 sm:mt-6 pt-4 border-t border-slate-100 flex items-center justify-end">
                    <a href="http://asy-syaakiriin.com/" target="_blank" rel="noopener noreferrer" class="px-3.5 sm:px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm flex items-center gap-1.5 transition-all">
                        <span>Kunjungi Website</span>
                        <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                    </a>
                </div>
            </div>

        </div>

    </div>

    <!-- Clean Transition Divider into Showcase Section -->
    <div class="w-full overflow-hidden leading-none select-none pointer-events-none -mb-[1px] mt-12">
        <svg class="relative block w-full h-12 sm:h-16 lg:h-20 text-[#FAFAFC]" viewBox="0 0 1440 100" fill="none" preserveAspectRatio="none">
            <defs>
                <linearGradient id="heroWaveStroke" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#4F46E5" stop-opacity="0.3" />
                    <stop offset="50%" stop-color="#06B6D4" stop-opacity="0.5" />
                    <stop offset="100%" stop-color="#8B5CF6" stop-opacity="0.3" />
                </linearGradient>
            </defs>
            <!-- Layer 1: Solid section transition fill -->
            <path d="M0,45 C320,95 540,15 820,55 C1100,95 1280,20 1440,50 L1440,100 L0,100 Z" fill="#FAFAFC"></path>
            <!-- Layer 2: Clean subtle crest stroke -->
            <path d="M0,45 C320,95 540,15 820,55 C1100,95 1280,20 1440,50" stroke="url(#heroWaveStroke)" stroke-width="2" fill="none"></path>
        </svg>
    </div>
</section>
