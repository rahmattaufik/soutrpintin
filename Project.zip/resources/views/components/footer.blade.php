<!-- Full-Width Wave (Ombak) Footer -->
<footer class="relative z-20 w-full overflow-hidden text-slate-400 mt-0">
    
    <!-- Smooth SVG Wave Divider at Top (Bold, Deep & Glowing Crest) -->
    <div class="w-full overflow-hidden leading-none select-none pointer-events-none -mb-[1px]">
        <svg class="relative block w-full h-12 sm:h-20 md:h-24 lg:h-28 text-[#0B132B]" viewBox="0 0 1440 100" fill="none" preserveAspectRatio="none">
            <defs>
                <linearGradient id="waveBorderGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#4F46E5" stop-opacity="0.75" />
                    <stop offset="50%" stop-color="#06B6D4" stop-opacity="1.0" />
                    <stop offset="100%" stop-color="#8B5CF6" stop-opacity="0.75" />
                </linearGradient>
            </defs>

            <!-- Layer 1: Soft Cyan/Indigo Ambient Wave Behind -->
            <path d="M0,30 C320,90 480,10 720,40 C960,70 1160,10 1440,30 L1440,100 L0,100 Z" fill="rgba(6, 182, 212, 0.2)"></path>

            <!-- Layer 2: Main Navy Solid Wave Body -->
            <path d="M0,45 C340,105 520,20 720,55 C920,90 1140,20 1440,45 L1440,100 L0,100 Z" fill="#0B132B"></path>

            <!-- Layer 3: Bold Neon Glowing Crest Line (4.5px) -->
            <path d="M0,45 C340,105 520,20 720,55 C920,90 1140,20 1440,45" fill="none" stroke="url(#waveBorderGlow)" stroke-width="4.5"></path>

            <!-- Layer 4: Secondary Dashed Wave Crest -->
            <path d="M0,35 C320,95 480,15 720,45 C960,75 1160,15 1440,35" fill="none" stroke="url(#waveBorderGlow)" stroke-width="2.5" stroke-dasharray="12 6" opacity="0.65"></path>
        </svg>
    </div>

    <!-- Main Footer Body (Full Width Edge-to-Edge Navy) -->
    <div class="w-full bg-[#0B132B] pt-8 sm:pt-10 pb-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 sm:gap-10 pb-10 border-b border-slate-800/80">
                
                <!-- Col 1: Brand Info (2 cols) -->
                <div class="sm:col-span-2 lg:col-span-2 space-y-4">
                    <a href="{{ route('home') }}" class="inline-flex items-center gap-3 group">
                        <div class="w-10 h-10 rounded-xl overflow-hidden p-[1px] bg-gradient-to-tr from-cyan-400 to-indigo-600 shadow-md group-hover:scale-105 transition-transform">
                            <img src="{{ asset('images/logosoutprint.jpeg') }}" alt="Logo Soutprint.In" class="w-full h-full object-cover rounded-[10px]">
                        </div>
                        <div>
                            <span class="text-xl font-black text-white font-heading">Soutprint<span class="text-cyan-400">.In</span></span>
                            <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Web Engineering &amp; Creative Studio</p>
                        </div>
                    </a>

                    <p class="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
                        Studio profesional spesialis pembuatan website modern berstandar internasional: Company Profile, E-Commerce berkonversi tinggi, Portal Properti, dan Custom Web Application.
                    </p>

                    <!-- Social Links -->
                    <div class="flex items-center gap-2.5 pt-1">
                        <a href="https://wa.me/6281234567890" target="_blank" aria-label="WhatsApp" class="w-8.5 h-8.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-emerald-500 hover:text-emerald-400 text-slate-400 flex items-center justify-center transition-all">
                            <i class="fa-brands fa-whatsapp text-sm"></i>
                        </a>
                        <a href="https://instagram.com" target="_blank" aria-label="Instagram" class="w-8.5 h-8.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-pink-500 hover:text-pink-400 text-slate-400 flex items-center justify-center transition-all">
                            <i class="fa-brands fa-instagram text-sm"></i>
                        </a>
                        <a href="https://linkedin.com" target="_blank" aria-label="LinkedIn" class="w-8.5 h-8.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-blue-500 hover:text-blue-400 text-slate-400 flex items-center justify-center transition-all">
                            <i class="fa-brands fa-linkedin-in text-sm"></i>
                        </a>
                        <a href="https://github.com" target="_blank" aria-label="GitHub" class="w-8.5 h-8.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-slate-400 hover:text-white text-slate-400 flex items-center justify-center transition-all">
                            <i class="fa-brands fa-github text-sm"></i>
                        </a>
                    </div>
                </div>

                <!-- Col 2: Layanan -->
                <div class="space-y-3">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                        <span>Layanan Web</span>
                    </h4>
                    <ul class="space-y-2 text-xs">
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">Company Profile Korporat</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">E-Commerce &amp; Toko Online</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">Custom Web Application</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">High-Conversion Landing Page</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">Redesign &amp; SEO Boost</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">Cloud Maintenance Care</a></li>
                    </ul>
                </div>

                <!-- Col 3: Halaman & Navigasi -->
                <div class="space-y-3">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                        <span>Navigasi Halaman</span>
                    </h4>
                    <ul class="space-y-2 text-xs">
                        <li><a href="{{ route('home') }}" class="hover:text-cyan-400 transition-colors">Beranda Utama</a></li>
                        <li><a href="{{ route('portfolio') }}" class="hover:text-cyan-400 transition-colors">Koleksi Portofolio</a></li>
                        <li><a href="{{ route('services') }}" class="hover:text-cyan-400 transition-colors">Paket &amp; Layanan</a></li>
                        <li><a href="{{ route('about') }}" class="hover:text-cyan-400 transition-colors">Alur Standar Mutu</a></li>
                        <li><a href="{{ route('faq') }}" class="hover:text-cyan-400 transition-colors">Tanya Jawab (FAQ)</a></li>
                        <li><a href="{{ route('contact') }}" class="hover:text-cyan-400 transition-colors">Hubungi Kami</a></li>
                    </ul>
                </div>

                <!-- Col 4: Kontak & Alamat -->
                <div class="space-y-3">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        <span>Hubungi Kami</span>
                    </h4>
                    <ul class="space-y-2.5 text-xs">
                        <li class="flex items-start gap-2.5 text-slate-300">
                            <i class="fa-solid fa-location-dot text-cyan-400 mt-0.5"></i>
                            <span>Jakarta &amp; Surabaya, Indonesia</span>
                        </li>
                        <li class="flex items-center gap-2.5 text-slate-300">
                            <i class="fa-solid fa-envelope text-cyan-400"></i>
                            <span>halo@soutprint.in</span>
                        </li>
                        <li class="flex items-center gap-2.5 text-slate-300">
                            <i class="fa-brands fa-whatsapp text-emerald-400"></i>
                            <span>+62 812-3456-7890</span>
                        </li>
                        <li class="flex items-center gap-2.5 text-slate-400">
                            <i class="fa-solid fa-clock text-slate-500"></i>
                            <span>Senin - Sabtu: 08:30 - 20:00 WIB</span>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- Bottom Copyright -->
            <div class="pt-6 text-center sm:text-left text-xs text-slate-400 border-t border-slate-800/60">
                <p>© {{ date('Y') }} <span class="text-slate-200 font-bold">Soutprint.In</span>. All rights reserved. Crafted with excellence &amp; modern engineering.</p>
            </div>

        </div>
    </div>
</footer>
