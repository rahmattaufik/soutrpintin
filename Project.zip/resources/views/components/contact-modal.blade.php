<div id="contact-modal" class="fixed inset-0 z-50 hidden bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
    <div class="relative w-full max-w-xl bg-white border border-slate-200 rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-2xl overflow-y-auto max-h-[90vh] text-slate-800">
        
        <!-- Close Button -->
        <button type="button" onclick="closeContactModal()" class="absolute top-4 right-4 sm:top-5 sm:right-5 text-slate-400 hover:text-slate-900 text-lg w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center transition-colors" aria-label="Tutup form">
            <i class="fa-solid fa-xmark"></i>
        </button>

        <!-- Header -->
        <div class="mb-5 sm:mb-6 pr-8 sm:pr-0">
            <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold mb-2 border border-indigo-200">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>Konsultasi Proyek Gratis</span>
            </div>
            <h3 class="text-xl sm:text-2xl font-bold text-slate-900 font-heading">Mulai Diskusi dengan Soutprint.In</h3>
            <p class="text-xs sm:text-sm text-slate-600 mt-1">
                Ceritakan kebutuhan website Anda. Tim kami akan merespons dalam hitungan menit untuk membahas estimasi biaya &amp; timeline.
            </p>
        </div>

        <!-- Form -->
        <form id="contact-form" action="{{ route('contact.submit') }}" method="POST" class="space-y-4">
            @csrf
            <input type="hidden" name="source" id="modal-source" value="Website General">

            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1.5">Nama Lengkap / Perusahaan *</label>
                <input type="text" name="name" id="modal-name" required placeholder="Contoh: Rendy Pratama / PT Maju Digital" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1.5">Nomor WhatsApp Aktif *</label>
                    <input type="tel" name="phone" id="modal-phone" required placeholder="Contoh: 08123456789" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1.5">Email Bisnis *</label>
                    <input type="email" name="email" id="modal-email" required placeholder="nama@perusahaan.com" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors">
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1.5">Pilihan Layanan</label>
                    <select name="service" id="modal-service" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 outline-none transition-colors">
                        <option value="Company Profile">Company Profile &amp; Korporat</option>
                        <option value="E-Commerce">E-Commerce &amp; Toko Online</option>
                        <option value="Web Application / SaaS">Web Application &amp; SaaS Kustom</option>
                        <option value="Landing Page">High-Conversion Landing Page</option>
                        <option value="Web Redesign">Redesign &amp; Performance Boost</option>
                        <option value="Custom Project">Proyek Kustom Lainnya</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1.5">Estimasi Budget</label>
                    <select name="budget" id="modal-budget" class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 outline-none transition-colors">
                        <option value="< Rp 3.000.000">&lt; Rp 3.000.000</option>
                        <option value="Rp 3.000.000 - Rp 7.000.000">Rp 3jt - Rp 7jt</option>
                        <option value="Rp 7.000.000 - Rp 15.000.000">Rp 7jt - Rp 15jt</option>
                        <option value="> Rp 15.000.000">&gt; Rp 15.000.000</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-700 mb-1.5">Deskripsi Singkat Kebutuhan / Referensi Website</label>
                <textarea name="message" id="modal-message" rows="3" required placeholder="Contoh: Kami butuh website toko online dengan fitur payment gateway otomatis dan kalkulasi ongkir untuk produk fashion..." class="w-full px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl bg-slate-50 border border-slate-300 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 text-xs sm:text-sm text-slate-900 placeholder-slate-400 outline-none transition-colors"></textarea>
            </div>

            <!-- Submit buttons -->
            <div class="pt-2 flex flex-col sm:flex-row gap-2.5 sm:gap-3">
                <button type="button" onclick="sendFormToWhatsApp()" class="flex-1 py-3 sm:py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 hover:to-green-400 shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center gap-2">
                    <i class="fa-brands fa-whatsapp text-lg"></i>
                    <span>Kirim Langsung ke WhatsApp</span>
                </button>
                <button type="submit" id="modal-submit-btn" class="flex-1 py-3 sm:py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/25 transition-all flex items-center justify-center gap-2">
                    <i class="fa-solid fa-paper-plane text-xs"></i>
                    <span>Kirim via Email / Server</span>
                </button>
            </div>
        </form>

        <p class="text-[11px] text-slate-500 text-center mt-4">
            🔒 Informasi Anda aman 100%. Kami menjaga kerahasiaan data privasi sesuai standar profesional.
        </p>

    </div>
</div>
