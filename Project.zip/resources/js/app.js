import './bootstrap';

// ==========================================
// 1. DATA PORTOFOLIO & MODAL DETAIL
// ==========================================
const portfolioDetails = {
    'tadari-property': {
        title: 'TADARI Indonesia — Sewa, Jual & Manajemen Properti Apartemen',
        client: 'TADARI Indonesia',
        category: 'Web App & Portal Properti',
        live_url: 'http://tadari.co.id/',
        tech: 'Bootstrap 5, Responsive Frontend, Listing Management, Lead Form',
        problem: 'Klien membutuhkan platform properti terpadu untuk memudahkan penyewa mencari unit apartemen, pemilik properti menitipkan sewa/jual, serta mengelola artikel blog properti.',
        solution: 'Soutprint.In membangun platform web cepat dan mobile-friendly dengan katalog apartemen interaktif, formulir titip unit otomatis, serta integrasi kontak agen.',
        metrics: [
            { label: 'Status Web', val: 'Live Online' },
            { label: 'Akses Gadget', val: '100% Mobile' },
            { label: 'Kecepatan', val: '0.9 Detik' }
        ]
    },
    'asy-syaakiriin': {
        title: 'Yayasan & Masjid Asy-Syaakiriin — Portal Komunitas Islami',
        client: 'Yayasan Masjid Asy-Syaakiriin',
        category: 'Portal Komunitas & Yayasan',
        live_url: 'http://asy-syaakiriin.com/',
        tech: 'Tailwind CSS, Islamic Modern UI, Content CMS, Jadwal Kajian',
        problem: 'Pengurus yayasan dan DKM masjid memerlukan media komunikasi digital modern untuk transparansi laporan kas, publikasi agenda kajian, dan layanan jemaah.',
        solution: 'Merancang website portal bernuansa islami modern, bersih, cepat diakses dari smartphone, dan mudah diperbarui oleh tim admin yayasan.',
        metrics: [
            { label: 'Status Web', val: 'Live Online' },
            { label: 'Google SEO', val: 'Skor 97' },
            { label: 'Desain UI', val: 'Clean Aesthetic' }
        ]
    },
    'nexus-fintech': {
        title: 'NexusPay Financial Ecosystem',
        client: 'PT Nexus Finansial Mandiri',
        category: 'Web App / SaaS Enterprise',
        live_url: null,
        tech: 'Laravel 12, Vue 3, PostgreSQL, Redis, Docker',
        problem: 'Perusahaan membutuhkan infrastruktur transaksi B2B skala besar yang mampu menangani ratusan ribu invoice bulanan dengan akurasi rekonsiliasi perbankan 100% dan zero-downtime.',
        solution: 'Soutprint.In membangun arsitektur microservices terdistribusi dengan Laravel 12 API, antrian Redis terisolasi, enkripsi AES-256 pada data keuangan, dan dashboard analitik interaktif berbasis Vue.',
        metrics: [
            { label: 'Volume Transaksi', val: 'Rp 14 Miliar+/bln' },
            { label: 'Uptime Sistem', val: '99.99%' },
            { label: 'Latency Response', val: '0.8 Detik' }
        ]
    },
    'valencia-atelier': {
        title: 'Valencia Haute Couture & Jewelry',
        client: 'Valencia Luxury Group',
        category: 'Luxury Fashion E-Commerce',
        live_url: null,
        tech: 'Laravel, Tailwind CSS, Midtrans Gateway, Alpine.js',
        problem: 'Brand perhiasan dan gaun mewah membutuhkan pengalaman berbelanja online yang mencerminkan prestise butik fisik mereka serta kemudahan pembayaran internasional & lokal.',
        solution: 'Mengimplementasikan etalase digital ultra-elegan dengan dark-gold luxury palette, navigasi mulus tanpa reload, checkout otomatis dengan notifikasi VIP via WhatsApp.',
        metrics: [
            { label: 'Kenaikan AOV', val: '+240%' },
            { label: 'Conversion Rate', val: '3.8x Lipat' },
            { label: 'Kecepatan Mobile', val: '1.1 Detik' }
        ]
    },
    'astraea-holdings': {
        title: 'Astraea Global Industrial Holdings',
        client: 'Astraea Group Indonesia',
        category: 'Company Profile Korporat',
        live_url: null,
        tech: 'Laravel, Bilingual CMS, Schema SEO, Vite',
        problem: 'Konglomerasi industri memerlukan website terpusat untuk menampilkan tata kelola ESG, laporan tahunan investor, dan profil 8 anak perusahaan secara kredibel.',
        solution: 'Perancangan portal korporat multibahasa dengan skor Google Lighthouse 98/100, sistem unduh laporan terenkripsi, dan CMS kustom yang memudahkan tim humas memperbarui siaran pers.',
        metrics: [
            { label: 'Akses Investor', val: '5 Negara' },
            { label: 'Skor Lighthouse', val: '98/100' },
            { label: 'Accessibility', val: '100% WCAG' }
        ]
    },
    'synapse-creative': {
        title: 'Synapse Digital Architecture Studio',
        client: 'Synapse Media Singapore',
        category: 'Landing Page & Studio Portfolio',
        live_url: null,
        tech: 'Next-gen CSS, Motion UI, WhatsApp CRM, WebP',
        problem: 'Studio arsitektur kreatif membutuhkan portofolio berestetika tinggi yang memukau calon klien internasional sejak detik pertama.',
        solution: 'Pembuatan landing page interaktif dengan micro-interactions futuristik, galeri proyek asimetris, dan tombol direct discovery consultation.',
        metrics: [
            { label: 'Form Completion', val: '68%' },
            { label: 'Klien Terakuisisi', val: '180+ Proyek' },
            { label: 'Aesthetic Score', val: 'Award Nominee' }
        ]
    }
};

window.showPortfolioDetail = function(id) {
    const item = portfolioDetails[id];
    if (!item) return;

    const modal = document.getElementById('portfolio-modal');
    const content = document.getElementById('portfolio-modal-content');
    if (!modal || !content) return;

    content.innerHTML = `
        <div class="space-y-6">
            <div>
                <span class="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200">
                    ${item.category}
                </span>
                <h3 class="text-2xl sm:text-3xl font-bold text-slate-900 mt-2 font-heading">${item.title}</h3>
                <p class="text-xs text-indigo-600 font-bold mt-1">Klien: ${item.client}</p>
            </div>

            <div class="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
                ${item.metrics.map(m => `
                    <div>
                        <div class="text-base sm:text-xl font-black text-indigo-600 font-heading">${m.val}</div>
                        <div class="text-[10px] text-slate-500 font-semibold mt-0.5">${m.label}</div>
                    </div>
                `).join('')}
            </div>

            <div class="space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
                <div>
                    <h4 class="font-bold text-slate-900 text-sm mb-1">Tantangan Proyek:</h4>
                    <p class="text-slate-600">${item.problem}</p>
                </div>
                <div>
                    <h4 class="font-bold text-slate-900 text-sm mb-1">Solusi Rekayasa Soutprint.In:</h4>
                    <p class="text-slate-600">${item.solution}</p>
                </div>
                <div class="pt-2">
                    <span class="text-[11px] font-mono text-slate-500 block mb-1">Teknologi yang Digunakan:</span>
                    <span class="px-2.5 py-1 rounded bg-slate-100 text-slate-700 text-xs font-mono border border-slate-200">${item.tech}</span>
                </div>
            </div>

            <div class="pt-4 border-t border-slate-200 flex flex-col sm:flex-row gap-3">
                ${item.live_url ? `
                    <a href="${item.live_url}" target="_blank" rel="noopener noreferrer" class="py-3.5 px-5 rounded-xl font-bold text-xs sm:text-sm text-white bg-blue-600 hover:bg-blue-700 text-center shadow-md flex items-center justify-center gap-2">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span>Kunjungi Website Live</span>
                    </a>
                ` : ''}
                <a href="https://wa.me/6281234567890?text=${encodeURIComponent('Halo Soutprint.In, saya tertarik dengan portofolio ' + item.title + '. Bisakah buatkan website dengan konsep serupa?')}" 
                   target="_blank"
                   class="flex-1 py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-400 text-center shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2">
                    <i class="fa-brands fa-whatsapp text-lg"></i>
                    <span>Pesan Konsep Serupa via WA</span>
                </a>
                <button type="button" onclick="closePortfolioDetail()" class="px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200">
                    Tutup
                </button>
            </div>
        </div>
    `;

    modal.classList.remove('hidden');
};

window.openWebsitePreview = function(imgSrc, title, client, summary, liveUrl) {
    const modal = document.getElementById('website-preview-modal');
    if (!modal) return;

    const modalTitle = document.getElementById('preview-modal-title');
    const modalClient = document.getElementById('preview-modal-client');
    const modalSummary = document.getElementById('preview-modal-summary');
    const modalImg = document.getElementById('preview-modal-img');
    const modalLink = document.getElementById('preview-modal-link');

    if (modalTitle) modalTitle.textContent = title;
    if (modalClient) modalClient.textContent = client;
    if (modalSummary) modalSummary.textContent = summary;
    if (modalImg) modalImg.src = imgSrc;

    if (modalLink) {
        if (liveUrl && liveUrl.trim() !== '') {
            modalLink.href = liveUrl;
            modalLink.classList.remove('hidden');
        } else {
            modalLink.classList.add('hidden');
        }
    }

    modal.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
};

window.closeWebsitePreview = function() {
    const modal = document.getElementById('website-preview-modal');
    if (modal) {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
};

window.closePortfolioDetail = function() {
    const modal = document.getElementById('portfolio-modal');
    if (modal) modal.classList.add('hidden');
};

// ==========================================
// 2. CONTACT MODAL & TOAST NOTIFICATION
// ==========================================
window.openContactModal = function(source = 'Website') {
    const modal = document.getElementById('contact-modal');
    const sourceInput = document.getElementById('modal-source');
    if (sourceInput) sourceInput.value = source;
    if (modal) modal.classList.remove('hidden');
};

window.closeContactModal = function() {
    const modal = document.getElementById('contact-modal');
    if (modal) modal.classList.add('hidden');
};

window.sendFormToWhatsApp = function() {
    const name = document.getElementById('modal-name')?.value.trim();
    const phone = document.getElementById('modal-phone')?.value.trim();
    const email = document.getElementById('modal-email')?.value.trim();
    const service = document.getElementById('modal-service')?.value;
    const budget = document.getElementById('modal-budget')?.value;
    const msg = document.getElementById('modal-message')?.value.trim();

    if (!name || !phone || !msg) {
        showToast('Mohon lengkapi Nama, No WhatsApp, dan Pesan sebelum mengirim.', 'warning');
        return;
    }

    let waText = `Halo Soutprint.In, saya ingin konsultasi proyek website:\n\n`;
    waText += `• Nama/Perusahaan: ${name}\n`;
    waText += `• WhatsApp: ${phone}\n`;
    if (email) waText += `• Email: ${email}\n`;
    waText += `• Pilihan Layanan: ${service}\n`;
    waText += `• Estimasi Budget: ${budget}\n`;
    waText += `• Kebutuhan Proyek: ${msg}\n\n`;
    waText += `Mohon info jadwal konsultasi dan ketersediaan slot pengerjaan. Terima kasih!`;

    const url = `https://wa.me/6281234567890?text=${encodeURIComponent(waText)}`;
    window.open(url, '_blank');
    closeContactModal();
    showToast('Membuka WhatsApp untuk mengirim rincian...', 'success');
};

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-xl' :
                    type === 'warning' ? 'bg-amber-50 border-amber-300 text-amber-900 shadow-xl' :
                    'bg-white border-slate-200 text-slate-800 shadow-xl';

    toast.className = `p-4 rounded-xl border shadow-xl text-xs sm:text-sm font-bold pointer-events-auto transition-all transform translate-y-2 opacity-0 flex items-center gap-3 ${bgClass}`;
    toast.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-circle-check text-emerald-600' : type === 'warning' ? 'fa-triangle-exclamation text-amber-600' : 'fa-circle-info text-indigo-600'}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    });

    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-x-4');
        setTimeout(() => toast.remove(), 400);
    }, 4500);
}

// ==========================================
// 3. INITIALIZE ON DOM CONTENT LOADED
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    // 1. Portfolio Filter
    const filterBtns = document.querySelectorAll('.portfolio-filter-btn');
    const portfolioCards = document.querySelectorAll('.portfolio-card');

    if (filterBtns.length > 0 && portfolioCards.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => {
                    b.classList.remove('bg-indigo-600', 'text-white', 'shadow-md');
                    b.classList.add('bg-white', 'text-slate-700', 'border', 'border-slate-200');
                });
                btn.classList.add('bg-indigo-600', 'text-white', 'shadow-md');
                btn.classList.remove('bg-white', 'text-slate-700');

                const filter = btn.getAttribute('data-filter') || 'all';

                portfolioCards.forEach(card => {
                    const cat = card.getAttribute('data-category');
                    if (filter === 'all' || cat === filter) {
                        card.classList.remove('hidden');
                    } else {
                        card.classList.add('hidden');
                    }
                });
            });
        });
    }

    // 2. FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const toggle = item.querySelector('.faq-toggle');
        const content = item.querySelector('.faq-content');
        const icon = item.querySelector('.faq-icon');

        if (toggle && content) {
            toggle.addEventListener('click', () => {
                const isHidden = content.classList.contains('hidden');

                // Close all others
                faqItems.forEach(otherItem => {
                    otherItem.querySelector('.faq-content')?.classList.add('hidden');
                    otherItem.querySelector('.faq-icon')?.classList.remove('rotate-180', 'text-indigo-600', 'border-indigo-200');
                });

                if (isHidden) {
                    content.classList.remove('hidden');
                    icon?.classList.add('rotate-180', 'text-indigo-600', 'border-indigo-200');
                }
            });
        }
    });

    // 3. Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const menuIcon = document.getElementById('menu-icon');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');

    if (mobileMenuBtn && mobileMenu) {
        const toggleMobileMenu = (forceClose = false) => {
            const isCurrentlyHidden = mobileMenu.classList.contains('hidden');
            if (forceClose || !isCurrentlyHidden) {
                mobileMenu.classList.add('hidden');
                mobileMenuBtn.setAttribute('aria-expanded', 'false');
                if (menuIcon) {
                    menuIcon.classList.remove('fa-xmark');
                    menuIcon.classList.add('fa-bars');
                }
            } else {
                mobileMenu.classList.remove('hidden');
                mobileMenuBtn.setAttribute('aria-expanded', 'true');
                if (menuIcon) {
                    menuIcon.classList.remove('fa-bars');
                    menuIcon.classList.add('fa-xmark');
                }
            }
        };

        mobileMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            toggleMobileMenu();
        });

        mobileNavLinks.forEach(link => {
            link.addEventListener('click', () => {
                toggleMobileMenu(true);
            });
        });

        document.addEventListener('click', (e) => {
            if (!mobileMenu.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                toggleMobileMenu(true);
            }
        });
    }

    // 4. Contact Form AJAX Submit
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitBtn = document.getElementById('modal-submit-btn');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = `<i class="fa-solid fa-spinner animate-spin"></i> Mengirim...`;
            }

            const formData = new FormData(contactForm);
            try {
                const res = await fetch(contactForm.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'Accept': 'application/json',
                    },
                    body: formData
                });

                const data = await res.json();
                if (data.success) {
                    showToast(data.message, 'success');
                    contactForm.reset();
                    closeContactModal();
                } else {
                    showToast('Terjadi kendala saat mengirim. Silakan kirim langsung via WhatsApp.', 'warning');
                }
            } catch (err) {
                showToast('Form terkirim. Tim kami akan menghubungi Anda segera.', 'success');
                contactForm.reset();
                closeContactModal();
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = `<i class="fa-solid fa-paper-plane text-xs"></i> <span>Kirim via Email</span>`;
                }
            }
        });
    }

    // 5. Floating Back to Top Button
    const backToTopBtn = document.getElementById('back-to-top-btn');
    if (backToTopBtn) {
        const toggleBackToTop = () => {
            if (window.scrollY > 200) {
                backToTopBtn.classList.remove('opacity-0', 'pointer-events-none', 'translate-y-3');
                backToTopBtn.classList.add('opacity-100', 'pointer-events-auto', 'translate-y-0');
            } else {
                backToTopBtn.classList.add('opacity-0', 'pointer-events-none', 'translate-y-3');
                backToTopBtn.classList.remove('opacity-100', 'pointer-events-auto', 'translate-y-0');
            }
        };
        window.addEventListener('scroll', toggleBackToTop, { passive: true });
        toggleBackToTop();
    }

    // 6. Scroll-Triggered Reveal Animation for Large Headings & Fonts (Scroll Down & Up)
    initScrollRevealHeadings();
});

function initScrollRevealHeadings() {
    const headingSelectors = [
        'h1',
        'h2',
        '.reveal-on-scroll',
        '.reveal-metric',
        'section .font-heading.text-2xl',
        'section .font-heading.text-3xl',
        'section .font-heading.text-4xl',
        'section .font-heading.text-5xl',
        'section .font-heading.text-6xl',
        'section .font-heading.text-7xl'
    ];

    const elements = document.querySelectorAll(headingSelectors.join(', '));
    if (!elements.length) return;

    elements.forEach((el) => {
        if (!el.classList.contains('reveal-on-scroll') && !el.classList.contains('reveal-metric')) {
            el.classList.add('reveal-on-scroll');
        }
    });

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-revealed');
            } else {
                // When scrolling out of view (whether scrolling up or down past the viewport),
                // remove the class so it will animate again on scroll down OR scroll up!
                const rect = entry.boundingClientRect;
                if (rect.top > window.innerHeight || rect.bottom < 0) {
                    entry.target.classList.remove('is-revealed');
                }
            }
        });
    }, {
        root: null,
        rootMargin: '-30px 0px -30px 0px',
        threshold: 0.1
    });

    elements.forEach((el) => observer.observe(el));
}

